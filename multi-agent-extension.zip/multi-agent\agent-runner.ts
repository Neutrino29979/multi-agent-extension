/**
 * Agent Runner — Execute agents via spawn
 *
 * Spawn:  isolated pi --mode json -p --no-session process
 * Fork:   spawn with inherited main session context
 */

import { spawn } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { Message } from "@earendil-works/pi-ai";
import { withFileMutationQueue } from "@earendil-works/pi-coding-agent";
import type {
  AgentConfig,
  AgentSpec,
  ForkContext,
  RunResult,
  TeamContext,
} from "./types.ts";
import {
  MAX_NESTED_DEPTH,
  DEFAULT_TIMEOUT_MS,
  READONLY_TOOLS,
  emptyUsage,
  getFinal,
} from "./types.ts";

// ── Resolve Agent Spec ──

export function resolveSpec(agent: AgentConfig | AgentSpec): {
  name: string;
  systemPrompt: string;
  type?: string;
  tools?: string[];
  model?: string;
  maxTurns?: number;
  origin: string;
} {
  const a = "origin" in agent ? (agent as AgentConfig) : (agent as AgentSpec);

  // Priority: readonly > explicit tools > undefined (all tools)
  let tools: string[] | undefined;
  if (a.readonly) {
    tools = [...R_TOOLS];
  } else if (a.tools && a.tools.length > 0) {
    tools = [...a.tools];
  }

  // Apply disallowedTools as denylist: remove denied tools from the available set
  if (a.disallowedTools && a.disallowedTools.length > 0) {
    const denied = new Set(a.disallowedTools.map(t => t.toLowerCase()));
    if (tools) {
      tools = tools.filter(t => !denied.has(t.toLowerCase()));
    }
    // If no allowlist is specified, we cannot remove from "all tools" since
    // that list isn't known at extension time. The --disallowed-tools CLI flag
    // would be needed for full denylist support without an allowlist.
  }

  return {
    name: a.name || "inline-agent",
    systemPrompt: a.systemPrompt,
    type: a.type,
    tools,
    model: a.model,
    maxTurns: a.maxTurns,
    origin: "origin" in a ? (a as AgentConfig).origin : "inline",
  };
}

// ── Public API ──

export async function runAgent(
  agent: AgentConfig | AgentSpec,
  task: string,
  opts: {
    cwd: string;
    signal?: AbortSignal;
    produces?: string[];
    step?: number;
    onUpdate?: (result: RunResult) => void;
    timeout?: number;
    forkContext?: ForkContext;
    teamContext?: TeamContext;
    extensionPath?: string;
  },
): Promise<RunResult> {
  const spec = resolveSpec(agent);
  const depth = parseInt(process.env.PI_AGENT_DEPTH || "0", 10);
  return runSpawn(spec, task, { ...opts, depth });
}

// ── Temp File ──

async function writeTempFile(name: string, content: string): Promise<{ dir: string; filePath: string }> {
  const tmpDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pi-ma-"));
  const safe = name.replace(/[^\w.-]+/g, "_");
  const filePath = path.join(tmpDir, `agent-${safe}.md`);
  await withFileMutationQueue(filePath, async () => {
    await fs.promises.writeFile(filePath, content, { encoding: "utf-8", mode: 0o600 });
  });
  return { dir: tmpDir, filePath };
}

// ── Pi Invocation ──

function getPiInvocation(args: string[]): { command: string; args: string[] } {
  const script = process.argv[1];
  if (script && !script.startsWith("/$bunfs/") && fs.existsSync(script)) {
    return { command: process.execPath, args: [script, ...args] };
  }
  const execName = path.basename(process.execPath).toLowerCase();
  if (/^(node|bun)(\.exe)?$/.test(execName)) {
    return { command: "pi", args };
  }
  return { command: process.execPath, args };
}

// ── Concurrency ──

export async function mapWithLimit<TIn, TOut>(
  items: TIn[],
  limit: number,
  fn: (item: TIn, index: number) => Promise<TOut>,
): Promise<TOut[]> {
  if (items.length === 0) return [];
  const concurrency = Math.max(1, Math.min(limit, items.length));
  const results: TOut[] = new Array(items.length);
  let idx = 0;
  const workers = new Array(concurrency).fill(null).map(async () => {
    while (true) {
      const i = idx++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return results;
}

// ── Spawn ──

async function runSpawn(
  spec: ReturnType<typeof resolveSpec>,
  task: string,
  opts: {
    cwd: string;
    signal?: AbortSignal;
    produces?: string[];
    step?: number;
    onUpdate?: (result: RunResult) => void;
    timeout?: number;
    forkContext?: ForkContext;
    teamContext?: TeamContext;
    depth?: number;
  },
): Promise<RunResult> {
  const args: string[] = ["--mode", "json", "-p", "--no-session"];
  if (spec.model) args.push("--model", spec.model);
  if (spec.tools?.length) args.push("--tools", spec.tools.join(","));
  if (spec.maxTurns) args.push("--max-turns", String(spec.maxTurns));

  const currentDepth = opts.depth ?? 0;
  const canNest = currentDepth < MAX_NESTED_DEPTH - 1;

  let tmpDir: string | null = null;
  let tmpFile: string | null = null;

  const result: RunResult = {
    agent: spec.name,
    origin: spec.origin as RunResult["origin"],
    task,
    mode: "spawn",
    exitCode: 0,
    output: "",
    messages: [],
    stderr: "",
    usage: emptyUsage(),
    model: spec.model,
    filesProduced: [],
    step: opts.step,
    timedOut: false,
  };

  // ── Build system prompt with optional Fork context ──
  let systemPrompt = spec.systemPrompt;
  if (opts.forkContext && opts.forkContext.totalTurns > 0) {
    systemPrompt += `

## Fork Context — Previous Session History

This agent was forked from a main session with ${opts.forkContext.totalTurns} prior turns.
The following is the recent discussion context:

${opts.forkContext.recentMessages}
${opts.forkContext.referencedFiles.length > 0 ? `\n### Referenced Files\n${opts.forkContext.referencedFiles.join(", ")}` : ""}

---
Your task begins below. Use the above context to understand what has been discussed, then execute your assigned task.
`;
  }

  // Team context: shared message board for inter-agent communication
  if (opts.teamContext && opts.teamContext.memberNames.length > 1) {
    const memberList = opts.teamContext.memberNames
      .map((n, i) => `  ${i + 1}. **${n}**: ${opts.teamContext.memberTasks[i] || "N/A"}`)
      .join("\n");
    systemPrompt += `

## Team Mode — Shared Message Board & Task List

You are part of a team of agents working together.
Your shared team directory is: \`${opts.teamContext.teamDir}\`

### Team Members:
${memberList}

### Task List:
A shared task list is at \`${opts.teamContext.teamDir}/tasks.json\`. Check it to see your assigned task and its status.

### How to collaborate:
1. **Read your task**: Check \`tasks.json\` for your assigned task (look for your name in \`assignee\`)
2. **Check dependencies**: If your task has \`dependsOn\` entries, read the results of those tasks first
3. **Mark your task in progress**: Update your task's status from \`"pending"\` to \`"in_progress"\` in \`tasks.json\`
4. **Write your results**: Save your output to \`${opts.teamContext.teamDir}/{your-name}-result.json\`
5. **Mark your task completed**: Update your task's status to \`"completed"\` in \`tasks.json\`
6. **Read other members' results**: Check \`tasks.json\` and other \`*-result.json\` files to see what teammates have produced
7. **Produce your final output**: After completing your task, summarize your findings

---
Your task begins below.
`;
  }

  // Nested agent support: tell the agent it can spawn sub-agents
  if (canNest && !opts.teamContext) {
    systemPrompt += `

## Nested Agent Support

You have access to the \`create_agents\`, \`agent\`, and \`cleanup_agents\` tools.
If this task is complex, you can create sub-agents to help:
- Use \`create_agents\` to define specialized sub-agents
- Use \`agent\` to delegate tasks to them (single, parallel, chain, or team mode)
- Use \`cleanup_agents\` when done

This is nested level ${currentDepth + 1}. Maximum nesting depth is ${MAX_NESTED_DEPTH}.
`;
  }

  const emitUpdate = () => {
    if (opts.onUpdate) {
      opts.onUpdate({ ...result, messages: [...result.messages] });
    }
  };

  try {
    const tmp = await writeTempFile(spec.name, systemPrompt);
    tmpDir = tmp.dir;
    tmpFile = tmp.filePath;
    args.push("--append-system-prompt", tmpFile);

    let taskPrompt = task;
    if (opts.produces?.length) {
      taskPrompt += `\n\nExpected output files: ${opts.produces.join(", ")}`;
    }
    args.push(taskPrompt);

    let aborted = false;
    let timedOut = false;
    const timeoutMs = opts.timeout ?? DEFAULT_TIMEOUT_MS;

    const onAbort = () => {
      aborted = true;
      proc.kill("SIGTERM");
      setTimeout(() => { if (!proc.killed) proc.kill("SIGKILL"); }, 5000);
    };

    const bin = getPiInvocation(args);
    const env = { ...process.env, PI_AGENT_DEPTH: String(currentDepth + 1) };
    const proc = spawn(bin.command, bin.args, {
      cwd: opts.cwd,
      shell: false,
      stdio: ["ignore", "pipe", "pipe"],
      env,
    });

    // Register abort handler
    if (opts.signal) {
      if (opts.signal.aborted) {
        onAbort();
      } else {
        opts.signal.addEventListener("abort", onAbort, { once: true });
      }
    }

    const timeoutId = setTimeout(() => {
      timedOut = true;
      aborted = true;
      proc.kill("SIGTERM");
      setTimeout(() => { if (!proc.killed) proc.kill("SIGKILL"); }, 5000);
    }, timeoutMs);

    let buf = "";

    const processLine = (line: string) => {
      if (!line.trim()) return;
      let ev: any;
      try { ev = JSON.parse(line); } catch { return; }

      if (ev.type === "message_end" && ev.message) {
        const msg = ev.message as Message;
        result.messages.push(msg);
        if (msg.role === "assistant") {
          result.usage.turns++;
          const u = msg.usage;
          if (u) {
            result.usage.input += u.input || 0;
            result.usage.output += u.output || 0;
            result.usage.cacheRead += u.cacheRead || 0;
            result.usage.cacheWrite += u.cacheWrite || 0;
            result.usage.cost += u.cost?.total || 0;
            result.usage.contextTokens = u.totalTokens || 0;
          }
          if (!result.model && msg.model) result.model = msg.model;
          if (msg.stopReason) result.stopReason = msg.stopReason;
          if (msg.errorMessage) result.errorMessage = msg.errorMessage;
        }
        result.output = getFinal(result.messages);
        emitUpdate();
      }

      if (ev.type === "tool_result_end" && ev.message) {
        result.messages.push(ev.message as Message);
        result.output = getFinal(result.messages);
        emitUpdate();
      }
    };

    proc.stdout.on("data", (d: Buffer) => {
      buf += d.toString();
      const lines = buf.split("\n");
      buf = lines.pop() || "";
      for (const l of lines) processLine(l);
    });

    proc.stderr.on("data", (d: Buffer) => {
      result.stderr += d.toString();
    });

    const exitCode = await new Promise<number>((resolve) => {
      proc.on("close", (code: number | null) => {
        clearTimeout(timeoutId);

        // Process any remaining buffered output
        if (buf.trim()) processLine(buf);

        // Clean up abort listener to prevent leak
        if (opts.signal && !opts.signal.aborted) {
          opts.signal.removeEventListener("abort", onAbort);
        }

        resolve(code ?? 0);
      });

      proc.on("error", () => {
        clearTimeout(timeoutId);
        if (opts.signal && !opts.signal.aborted) {
          opts.signal.removeEventListener("abort", onAbort);
        }
        resolve(1);
      });
    });

    result.exitCode = exitCode;
    result.timedOut = timedOut;
    if (timedOut) {
      result.stopReason = "timeout";
      result.errorMessage = `Agent timed out after ${timeoutMs / 1000}s.`;
    } else if (aborted && !timedOut) {
      result.stopReason = "aborted";
      result.errorMessage = "Subagent was aborted.";
    }

    if (opts.produces) {
      result.filesProduced = opts.produces.filter((f) =>
        fs.existsSync(path.resolve(opts.cwd, f)),
      );
    }

    return result;
  } finally {
    if (tmpFile) try { fs.unlinkSync(tmpFile); } catch {}
    if (tmpDir) try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

