/**
 * Agent Registry — Discover, create, validate, and clean up agents
 *
 * Sources:
 *   1. ~/.pi/agent/agents/*.md  — global, shared across all projects
 *   2. .pi/agents/*.md          — project-local, created by AI or user
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { getAgentDir, parseFrontmatter } from "@earendil-works/pi-coding-agent";
import type { Message } from "@earendil-works/pi-ai";
import type {
  AgentConfig,
  AgentCreateRequest,
  AgentOrigin,
  AgentType,
  ForkContext,
} from "./types.ts";
import {
  FORK_MAX_TURNS,
  FORK_MAX_FILES,
  FORK_MSG_CHAR_LIMIT,
  FORK_TOOL_RESULT_LIMIT,
  FORK_MAX_RECENT_FILES,
  FILE_EXT_PATTERN,
} from "./types.ts";

// ── Discovery ──

export function discoverAgents(cwd: string): AgentConfig[] {
  const map = new Map<string, AgentConfig>();

  // Global agents (~/.pi/agent/agents/*.md)
  const globalDir = path.join(getAgentDir(), "agents");
  for (const a of loadDir(globalDir, "global")) {
    map.set(a.name, a);
  }

  // Project agents (.pi/agents/*.md) — override globals with same name
  const projectDir = findProjectAgentsDir(cwd);
  if (projectDir) {
    for (const a of loadDir(projectDir, "project")) {
      map.set(a.name, a);
    }
  }

  return [...map.values()];
}

// ── Validation ──

export function validateAgentRequest(request: AgentCreateRequest): string | null {
  if (!request.name || typeof request.name !== "string") {
    return "Agent name is required.";
  }
  if (request.name.length < 2 || request.name.length > 50) {
    return "Agent name must be between 2 and 50 characters.";
  }
  if (!/^[a-z0-9][a-z0-9-]*[a-z0-9]$/.test(request.name)) {
    return "Agent name must use only lowercase letters, numbers, and hyphens, and must start and end with alphanumeric characters.";
  }
  if (!request.description || typeof request.description !== "string") {
    return "Agent description is required.";
  }
  if (!request.systemPrompt || typeof request.systemPrompt !== "string") {
    return "System prompt is required.";
  }
  if (request.systemPrompt.trim().length < 10) {
    return "System prompt is too short (minimum 10 characters).";
  }
  if (request.type !== undefined && !["standard", "fork", "team"].includes(request.type)) {
    return 'Agent type must be "standard", "fork", or "team".';
  }
  if (request.tools !== undefined && !Array.isArray(request.tools)) {
    return "Tools must be an array of strings.";
  }
  return null;
}

// ── Creation ──

export function createAgentFile(
  cwd: string,
  request: AgentCreateRequest,
): { ok: true; path: string } | { ok: false; error: string } {
  const validationError = validateAgentRequest(request);
  if (validationError) {
    return { ok: false, error: validationError };
  }

  // Determine the target directory based on scope
  let dir: string | null;
  if (request.scope === "global") {
    dir = path.join(os.homedir(), ".pi", "agent", "agents");
    try { fs.mkdirSync(dir, { recursive: true }); } catch {
      return { ok: false, error: "Could not create ~/.pi/agent/agents/ directory." };
    }
  } else {
    dir = ensureProjectAgentsDir(cwd);
    if (!dir) {
      return { ok: false, error: "Could not create .pi/agents/ directory." };
    }
  }

  const filePath = path.join(dir, `${request.name}.md`);

  const yamlSafe = (v: string) => {
    if (/[:\{\}\[\],&#\*\?\|>!%@`\n\r]/.test(v) || v.trim() !== v) {
      return `"${v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n")}"`;
    }
    return v;
  };

  const frontmatter = [
    "---",
    `name: ${request.name}`,
    `description: ${yamlSafe(request.description)}`,
  ];
  if (request.type && request.type !== "standard") {
    frontmatter.push(`type: ${request.type}`);
  }
  if (request.tools && request.tools.length > 0) {
    frontmatter.push(`tools: ${request.tools.join(", ")}`);
  }
  if (request.disallowedTools && request.disallowedTools.length > 0) {
    frontmatter.push(`disallowedTools: ${request.disallowedTools.join(", ")}`);
  }
  if (request.maxTurns !== undefined && request.maxTurns !== null) {
    frontmatter.push(`maxTurns: ${request.maxTurns}`);
  }
  if (request.readonly) {
    frontmatter.push("readonly: true");
  }
  if (request.model) {
    frontmatter.push(`model: ${yamlSafe(request.model)}`);
  }
  frontmatter.push("---");

  const content = frontmatter.join("\n") + "\n\n" + request.systemPrompt;

  try {
    fs.writeFileSync(filePath, content, "utf-8");
  } catch (e: any) {
    return { ok: false, error: e.message || "Failed to write agent file." };
  }

  return { ok: true, path: filePath };
}

// ── Fork Context Collection ──

/**
 * Collect session context for Fork mode.
 * Extracts recent messages and file references from the session branch.
 */
export function collectForkContext(
  branchEntries: ReadonlyArray<{ type: string; message?: Message }>,
  maxTurns: number = FORK_MAX_TURNS,
): ForkContext {
  const msgs = branchEntries
    .filter((e) => e.type === "message" && e.message)
    .slice(-maxTurns);

  const referencedFiles = new Set<string>();
  const recentFiles = new Map<string, string>(); // path -> content
  const parts: string[] = [];

  for (const entry of msgs) {
    const m = entry.message!;
    const role = m.role === "user" ? "User" : m.role === "assistant" ? "Assistant" : "System";
    const texts: string[] = [];
    const toolResults: string[] = [];

    if (typeof m.content === "string") {
      texts.push(m.content);
    } else if (Array.isArray(m.content)) {
      for (const block of m.content) {
        if (block.type === "text") texts.push(block.text);
        // Preserve tool result summaries
        if (block.type === "tool_result" && block.content) {
          const resultText = typeof block.content === "string"
            ? block.content
            : Array.isArray(block.content)
              ? block.content.filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n")
              : "";
          if (resultText) {
            const name = (block as any).name || (block as any).tool_use_id || "tool";
            toolResults.push(`[${name}] ${resultText.slice(0, FORK_TOOL_RESULT_LIMIT)}`);
          }
        }
      }
    }

    for (const t of texts) {
      // Extract file references (paths mentioned in conversation)
      const fileRefs = t.match(FILE_EXT_PATTERN);
      if (fileRefs) {
        for (const f of fileRefs) referencedFiles.add(f);
      }
    }

    let part = `**${role}**: ${texts.join("\n").slice(0, FORK_MSG_CHAR_LIMIT)}`;
    if (toolResults.length > 0) {
      part += `\n${toolResults.join("\n")}`;
    }
    parts.push(part);
  }

  // Include full content of most recently referenced files (up to FORK_MAX_RECENT_FILES)
  for (const fPath of [...referencedFiles].slice(-FORK_MAX_RECENT_FILES)) {
    try {
      const resolved = fPath.startsWith("/") || fPath.startsWith("~")
        ? fPath
        : path.join(process.cwd(), fPath);
      if (fs.existsSync(resolved)) {
        const stat = fs.statSync(resolved);
        if (stat.isFile() && stat.size < 50 * 1024) { // Only include files < 50KB
          const content = fs.readFileSync(resolved, "utf-8");
          recentFiles.set(fPath, content);
        }
      }
    } catch {
      // Skip files that can't be read
    }
  }

  let recentFilesSection = "";
  if (recentFiles.size > 0) {
    recentFilesSection = "\n### Recently Referenced Files\n";
    for (const [fp, content] of recentFiles) {
      const ext = fp.split(".").pop() || "";
      const truncated = content.length > 3000 ? content.slice(0, 3000) + "\n... (truncated)" : content;
      recentFilesSection += `\n**${fp}**:\n\`${ext}\`\n${truncated}\n\`\`${ext}\`\n`;
    }
  }

  return {
    recentMessages: parts.join("\n\n"),
    referencedFiles: [...referencedFiles].slice(0, FORK_MAX_FILES),
    totalTurns: msgs.length,
  };
}

// Stub for the file-content injection (used by runSpawn)
export function getForkFileSection(forkCtx: ForkContext): string {
  // This is called in agent-runner.ts to build the file section
  // We keep it simple: referencedFiles list is enough, full content is injected by collectForkContext into recentMessages
  return forkCtx.referencedFiles.length > 0
    ? `Referenced files: ${forkCtx.referencedFiles.join(", ")}`
    : "";
}

// ── Cleanup ──

export function removeAgentFiles(cwd: string, names: string[]): { removed: string[]; errors: string[] } {
  const dir = findProjectAgentsDir(cwd);
  if (!dir) return { removed: [], errors: ["No .pi/agents/ directory found."] };

  const removed: string[] = [];
  const errors: string[] = [];

  for (const name of names) {
    const filePath = path.join(dir, `${name}.md`);
    if (!fs.existsSync(filePath)) {
      errors.push(`${name}: file not found`);
      continue;
    }
    try {
      fs.unlinkSync(filePath);
      removed.push(name);
    } catch (e: any) {
      errors.push(`${name}: ${e.message}`);
    }
  }

  return { removed, errors };
}

export function removeAllProjectAgents(cwd: string): { removed: string[]; errors: string[] } {
  const dir = findProjectAgentsDir(cwd);
  if (!dir) return { removed: [], errors: ["No .pi/agents/ directory found."] };

  const names: string[] = [];
  try {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.endsWith(".md")) {
        names.push(entry.name.replace(/\.md$/, ""));
      }
    }
  } catch {
    return { removed: [], errors: ["Failed to read .pi/agents/."] };
  }

  return removeAgentFiles(cwd, names);
}

// ── Formatting ──

export function formatAgentList(agents: AgentConfig[]): string {
  if (agents.length === 0) return "No agents found.";

  const globalAgents = agents.filter((a) => a.origin === "global");
  const projectAgents = agents.filter((a) => a.origin === "project");

  const parts: string[] = [];

  if (projectAgents.length > 0) {
    parts.push("**Project agents** (.pi/agents/):");
    for (const a of projectAgents) {
      const extras = [
        a.type && a.type !== "standard" ? `type: ${a.type}` : null,
        a.readonly ? "readonly" : null,
        a.model ? `model: ${a.model}` : null,
      ].filter(Boolean);
      parts.push(`  - **${a.name}**${extras.length ? ` (${extras.join(", ")})` : ""}: ${a.description}`);
    }
  }

  if (globalAgents.length > 0) {
    if (parts.length > 0) parts.push("");
    parts.push("**Global agents** (~/.pi/agent/agents/):");
    for (const a of globalAgents) {
      const extras = [
        a.type && a.type !== "standard" ? `type: ${a.type}` : null,
        a.readonly ? "readonly" : null,
        a.model ? `model: ${a.model}` : null,
      ].filter(Boolean);
      parts.push(`  - **${a.name}**${extras.length ? ` (${extras.join(", ")})` : ""}: ${a.description}`);
    }
  }

  return parts.join("\n");
}

// ── Internal ──

function loadDir(dir: string, origin: AgentOrigin): AgentConfig[] {
  if (!fs.existsSync(dir)) return [];

  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return [];
  }

  const agents: AgentConfig[] = [];
  for (const entry of entries) {
    if (!entry.name.endsWith(".md")) continue;
    if (!entry.isFile() && !entry.isSymbolicLink()) continue;

    const filePath = path.join(dir, entry.name);
    let content: string;
    try {
      content = fs.readFileSync(filePath, "utf-8");
    } catch {
      continue;
    }

    const { frontmatter, body } = parseFrontmatter<Record<string, string>>(content);
    if (!frontmatter.name || !frontmatter.description) continue;

    const type = frontmatter.type as AgentType | undefined;
    const readonly = frontmatter.readonly === "true" || frontmatter.readonly === true;

    // Parse tools: frontmatter stores them as comma-separated string
    let tools: string[] | undefined;
    if (frontmatter.tools && typeof frontmatter.tools === "string") {
      tools = frontmatter.tools.split(",").map((t: string) => t.trim()).filter(Boolean);
    }

    // Parse disallowedTools and maxTurns
    const disallowedTools = frontmatter.disallowedTools && typeof frontmatter.disallowedTools === "string"
      ? frontmatter.disallowedTools.split(",").map((t: string) => t.trim()).filter(Boolean)
      : undefined;
    const maxTurns = frontmatter.maxTurns ? parseInt(String(frontmatter.maxTurns), 10) : undefined;

    agents.push({
      name: frontmatter.name,
      description: frontmatter.description,
      systemPrompt: body,
      type: type && ["standard", "fork", "team"].includes(type) ? type : "standard",
      readonly,
      tools,
      disallowedTools,
      maxTurns: maxTurns && maxTurns > 0 ? maxTurns : undefined,
      origin,
      filePath,
    });
  }

  return agents;
}

function isDirectory(p: string): boolean {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function findProjectAgentsDir(cwd: string): string | null {
  let currentDir = cwd;
  while (true) {
    const candidate = path.join(currentDir, ".pi", "agents");
    if (isDirectory(candidate)) return candidate;
    const parentDir = path.dirname(currentDir);
    if (parentDir === currentDir) return null;
    currentDir = parentDir;
  }
}

function ensureProjectAgentsDir(cwd: string): string | null {
  const dir = path.join(cwd, ".pi", "agents");
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {
      return null;
    }
  }
  return dir;
}