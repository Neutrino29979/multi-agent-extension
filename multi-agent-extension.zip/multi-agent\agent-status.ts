/**
 * Agent Status — Tracking, session management, and formatting utilities
 *
 * Provides state management for agent execution status and TUI formatting helpers.
 * Consumed by agent-executor.ts and index.ts.
 */

import * as os from "node:os";
import type { Message } from "@earendil-works/pi-ai";
import type {
  AgentSession,
  AgentStatus,
  DisplayItem,
  RunResult,
  UsageStats,
} from "./types.ts";
import {
  MAX_SESSION_ENTRIES,
  MAX_STATUS_ENTRIES,
  OUTPUT_CAP_BYTES,
  totalUsage,
} from "./types.ts";

// ── Status Map ──

export const agentStatusMap = new Map<string, AgentStatus>();

export function getOrCreateEntry(name: string, step?: number): AgentStatus {
  let entry = agentStatusMap.get(name);
  if (!entry) {
    // Evict oldest entry if map is too large (FIFO)
    if (agentStatusMap.size >= MAX_STATUS_ENTRIES) {
      const firstKey = agentStatusMap.keys().next().value;
      if (firstKey) agentStatusMap.delete(firstKey);
    }
    entry = { name, status: "pending", usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, cost: 0, contextTokens: 0, turns: 0 }, step };
    agentStatusMap.set(name, entry);
  }
  return entry;
}

// ── Sessions ──

export const agentSessions: AgentSession[] = [];

export function addSession(session: Omit<AgentSession, "id" | "startTime">): AgentSession {
  const full: AgentSession = {
    id: `s-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    startTime: Date.now(),
    ...session,
  };
  agentSessions.unshift(full);
  // Proper eviction: splice instead of setting .length
  if (agentSessions.length > MAX_SESSION_ENTRIES) {
    agentSessions.splice(MAX_SESSION_ENTRIES);
  }
  refreshStatusIndicator();
  return full;
}

export function updateSession(id: string, updates: Partial<AgentSession>): void {
  const s = agentSessions.find((s) => s.id === id);
  if (s) Object.assign(s, updates);
  refreshStatusIndicator();
}

// ── Live Status Indicator ──

let _updateWidget: ((lines: string[] | undefined) => void) | null = null;

export function setUpdateWidget(fn: ((lines: string[] | undefined) => void) | null): void {
  _updateWidget = fn;
}

export function refreshStatusIndicator(): void {
  if (!_updateWidget) return;
  const running = agentSessions.filter((s) => s.status === "running").length;
  const done = agentSessions.filter((s) => s.status === "done").length;
  const failed = agentSessions.filter((s) => s.status === "failed").length;
  if (running === 0 && done === 0 && failed === 0) {
    _updateWidget(undefined);
    return;
  }
  const line = `  🤖  ${running} ⌛  ·  ${done} ✅  ·  ${failed} ❌`;
  _updateWidget([
    `  ╭─ Multi-Agent ───────────────────╮`,
    `  │ ${line.padEnd(34)}│`,
    `  ╰──────────────────────────────────╯`,
  ]);
}

// ── Formatting Utilities ──

export function fmtDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(0)}s`;
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${m}m${s}s`;
}

export function fmtTokens(n: number): string {
  if (n < 1000) return String(n);
  if (n < 10000) return `${(n / 1000).toFixed(1)}k`;
  if (n < 1_000_000) return `${Math.round(n / 1000)}k`;
  return `${(n / 1_000_000).toFixed(1)}M`;
}

export function fmtUsage(u: UsageStats, model?: string): string {
  const p: string[] = [];
  if (u.turns) p.push(`${u.turns}t`);
  if (u.input) p.push(`↑${fmtTokens(u.input)}`);
  if (u.output) p.push(`↓${fmtTokens(u.output)}`);
  if (u.cacheRead) p.push(`R${fmtTokens(u.cacheRead)}`);
  if (u.cacheWrite) p.push(`W${fmtTokens(u.cacheWrite)}`);
  if (u.cost) p.push(`$${u.cost.toFixed(4)}`);
  if (u.contextTokens > 0) p.push(`ctx:${fmtTokens(u.contextTokens)}`);
  if (model) p.push(model);
  return p.join(" ");
}

export function fmtTool(tool: string, args: Record<string, unknown>, fg: (c: string, t: string) => string): string {
  const short = (p: string) => p.startsWith(os.homedir()) ? `~${p.slice(os.homedir().length)}` : p;

  switch (tool) {
    case "bash": {
      const cmd = (args.command as string) || "...";
      return fg("muted", "$ ") + fg("toolOutput", cmd.length > 60 ? cmd.slice(0, 60) + "..." : cmd);
    }
    case "read": {
      const fp = short((args.file_path || args.path || "...") as string);
      const off = args.offset as number | undefined;
      const lim = args.limit as number | undefined;
      let t = fg("accent", fp);
      if (off != null || lim != null) {
        t += fg("warning", `:${off ?? 1}${lim ? `-${(off ?? 1) + lim - 1}` : ""}`);
      }
      return fg("muted", "read ") + t;
    }
    case "write": {
      const fp = short((args.file_path || args.path || "...") as string);
      const lines = ((args.content as string) || "").split("\n").length;
      return fg("muted", "write ") + fg("accent", fp) + (lines > 1 ? fg("dim", ` (${lines}l)`) : "");
    }
    case "edit":
      return fg("muted", "edit ") + fg("accent", short((args.file_path || args.path || "...") as string));
    case "ls":
      return fg("muted", "ls ") + fg("accent", short((args.path || ".") as string));
    case "find":
      return fg("muted", "find ") + fg("accent", (args.pattern || "*") as string) + fg("dim", ` in ${short((args.path || ".") as string)}`);
    case "grep":
      return fg("muted", "grep ") + fg("accent", `/${args.pattern || ""}/`) + fg("dim", ` in ${short((args.path || ".") as string)}`);
    default: {
      const s = JSON.stringify(args);
      return fg("accent", tool) + fg("dim", ` ${s.length > 50 ? s.slice(0, 50) + "..." : s}`);
    }
  }
}

export function displayItems(msgs: Message[]): DisplayItem[] {
  const items: DisplayItem[] = [];
  for (const m of msgs) {
    if (m.role === "assistant") {
      for (const p of m.content) {
        if (p.type === "text") items.push({ type: "text", text: p.text });
        else if (p.type === "toolCall") items.push({ type: "toolCall", name: p.name, args: p.arguments });
      }
    }
  }
  return items;
}

export function trunc(s: string): string {
  if (Buffer.byteLength(s, "utf8") <= OUTPUT_CAP_BYTES) return s;
  let t = s.slice(0, OUTPUT_CAP_BYTES);
  while (Buffer.byteLength(t, "utf8") > OUTPUT_CAP_BYTES) t = t.slice(0, -1);
  return t + `\n\n[Truncated: ${Buffer.byteLength(s, "utf8") - Buffer.byteLength(t, "utf8")} bytes]`;
}

// ── Dashboard ──

export function renderDashboard(fg: (c: string, t: string) => string): string {
  const entries = [...agentStatusMap.values()];
  if (entries.length === 0) return "";

  const lines: string[] = [fg("toolTitle", "Agent Status ") + fg("muted", "─".repeat(27))];

  for (const e of entries) {
    const icon = e.status === "done" ? fg("success", "✓")
      : e.status === "running" ? fg("warning", "⏳")
      : e.status === "failed" ? fg("error", "✗")
      : fg("muted", "○");

    const elapsed = e.startTime
      ? fmtDuration((e.endTime || Date.now()) - e.startTime)
      : "--";

    const tokens = e.usage.input || e.usage.output
      ? `↑${fmtTokens(e.usage.input)} ↓${fmtTokens(e.usage.output)}`
      : "";

    const cost = e.usage.cost ? ` $${e.usage.cost.toFixed(4)}` : "";

    let line = `  ${icon} ${fg("accent", e.name.padEnd(16))} ${fg("muted", elapsed.padStart(8))}`;
    if (tokens || cost) line += ` ${fg("dim", tokens + cost)}`;
    if (e.error) line += ` ${fg("error", e.error.slice(0, 40))}`;
    lines.push(line);
  }

  // Summary
  const totalTime = entries.reduce((sum, e) => {
    if (!e.startTime) return sum;
    return sum + ((e.endTime || Date.now()) - e.startTime);
  }, 0);
  const tu = totalUsage(entries.map((e) => ({ usage: e.usage }) as RunResult));
  const done = entries.filter((e) => e.status === "done").length;
  const failed = entries.filter((e) => e.status === "failed").length;
  const running = entries.filter((e) => e.status === "running").length;

  lines.push(fg("muted", "  " + "─".repeat(44)));
  let summary = `  ${fg("muted", "Total:")} ${fmtDuration(totalTime)}`;
  if (tu.input || tu.output) summary += ` ↑${fmtTokens(tu.input)} ↓${fmtTokens(tu.output)}`;
  if (tu.cost) summary += ` $${tu.cost.toFixed(4)}`;
  summary += ` ${fg("success", `${done}✓`)}${failed ? ` ${fg("error", `${failed}✗`)}` : ""}${running ? ` ${fg("warning", `${running}⏳`)}` : ""}`;
  lines.push(summary);

  return lines.join("\n");
}

