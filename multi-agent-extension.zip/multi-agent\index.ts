/**
 * Multi-Agent Extension — Registration and Entry Point
 *
 * Registers three tools (create_agents, agent, cleanup_agents),
 * the /agent command, and the #agent-name input routing.
 * All heavy logic lives in peer modules.
 */

import type { AgentToolResult } from "@earendil-works/pi-agent-core";
import {
  type ExtensionAPI,
  getMarkdownTheme,
} from "@earendil-works/pi-coding-agent";
import { StringEnum } from "@earendil-works/pi-ai";
import { Container, Markdown, Spacer, Text } from "@earendil-works/pi-tui";
import { Type } from "typebox";
import {
  createAgentFile,
  collectForkContext,
  discoverAgents,
  formatAgentList,
  removeAgentFiles,
  removeAllProjectAgents,
} from "./agent-registry.ts";
import {
  executeChainMode,
  executeParallelMode,
  executeSingleMode,
  executeTeamMode,
} from "./agent-executor.ts";
import {
  addSession,
  agentSessions,
  agentStatusMap,
  displayItems,
  fmtDuration,
  fmtTool,
  fmtTokens,
  fmtUsage,
  getOrCreateEntry,
  refreshStatusIndicator,
  renderDashboard,
  setUpdateWidget,
  trunc,
  updateSession,
} from "./agent-status.ts";
import {
  type AgentConfig,
  type AgentCreateRequest,
  type AgentToolDetail,
  type DisplayItem,
  type RunResult,
  COLLAPSED_ITEMS,
  SESSION_TEXT_CAP,
  emptyUsage,
  getFinal,
  isFailed,
  totalUsage,
} from "./types.ts";


// ── Entry ──

export default function (pi: ExtensionAPI) {

  // ── Session Start: Inject trigger instructions ──

  pi.on("before_agent_start", async (event, _ctx) => {
    const triggerInstructions = `

## Multi-Agent

You have access to the \`create_agents\` and \`agent\` tools. Use them whenever the user wants to create or run multiple agents.

### When to use create_agents

Use \`create_agents\` (with \`confirm: false\`) when the user mentions:
- Creating agents / 创建智能体
- Multiple agents / 多个智能体协作
- Assigning different models to agents / 给智能体分配不同模型
- Parallel or chained agent workflows / 并行或链式
- Delegating tasks to specialized agents
- Any phrase like "create 4 agents", "用不同的模型", "多个agent"

Rules:
1. Create all agents in one \`create_agents\` call, set \`confirm: false\`.
2. Give each agent only the tools it needs (least privilege).
3. Model format: \`provider/model-id\` (e.g. \`opencode-go/gpt-4o\`).

### When to use agent

After creating agents, use \`agent\` to invoke them. Choose:
- **parallel**: independent tasks run simultaneously
- **chain**: sequential tasks, use \`{previous}\` to pass output
- **single**: one agent, one task

### When NOT to use
- Simple tasks a single response can handle
- The user explicitly says not to use agents

### Check status
- Use \`/agent status\` to see running/finished agents
- Use \`/agent panel\` to open the interactive agent view
`;
    return { systemPrompt: (event.systemPrompt || "") + triggerInstructions };
  });

  // ── Session Start: Initiate status indicator + autocomplete ──

  pi.on("session_start", (_event, ctx) => {
    setUpdateWidget((lines) => ctx.ui.setWidget("agent-indicator", lines));
    refreshStatusIndicator();

    ctx.ui.addAutocompleteProvider((current) => ({
      triggerCharacters: ["#"],
      async getSuggestions(lines, cursorLine, cursorCol, options) {
        const line = lines[cursorLine] ?? "";
        const beforeCursor = line.slice(0, cursorCol);
        const match = beforeCursor.match(/(?:^|[ \t])#([^\s]*)$/);
        if (!match) {
          return current.getSuggestions(lines, cursorLine, cursorCol, options);
        }

        const prefix = match[1] ?? "";
        const agents = discoverAgents(ctx.cwd);

        const builtinItems = [
          { value: "#list-agents", label: "#list-agents", description: "列出所有可用 agent" },
          { value: "#help", label: "#help", description: "显示 # 命令帮助" },
        ];

        const agentItems = agents
          .filter((a) => a.name.startsWith(prefix))
          .map((a) => ({
            value: `#${a.name} `,
            label: `#${a.name}`,
            description: `${a.description}${a.readonly ? " [readonly]" : ""}${a.model ? ` @${a.model}` : ""}`,
          }));

        const allItems = [...builtinItems, ...agentItems];
        const filtered = allItems.filter((i) => i.value.startsWith(`#${prefix}`));

        return {
          prefix: `#${prefix}`,
          items: filtered.length > 0 ? filtered : allItems.slice(0, 5),
        };
      },
      applyCompletion(lines, cursorLine, cursorCol, item, prefix) {
        return current.applyCompletion(lines, cursorLine, cursorCol, item, prefix);
      },
      shouldTriggerFileCompletion(lines, cursorLine, cursorCol) {
        const line = lines[cursorLine] ?? "";
        const beforeCursor = line.slice(0, cursorCol);
        if (beforeCursor.includes("#")) return false;
        return current.shouldTriggerFileCompletion?.(lines, cursorLine, cursorCol) ?? true;
      },
    }));
  });

  // ── Input Event: #agent-name routing ──

  pi.on("input", async (event, ctx) => {
    const text = event.text;
    if (!text.startsWith("#")) return { action: "continue" };

    if (/^#list-agents\b/.test(text)) {
      const agents = discoverAgents(ctx.cwd);
      if (ctx.hasUI) {
        ctx.ui.notify(formatAgentList(agents), "info");
        return { action: "handled" };
      }
      return { action: "transform", text: `列出所有可用的 agent\n\n${formatAgentList(agents)}` };
    }

    if (/^#help\b/.test(text)) {
      const help = [
        "# 命令帮助：",
        "  #list-agents          - 列出所有可用 agent",
        "  #<agent-name> <任务>  - 直接调用指定 agent 执行任务",
        "  #help                 - 显示本帮助",
      ].join("\n");
      if (ctx.hasUI) {
        ctx.ui.notify(help, "info");
        return { action: "handled" };
      }
      return { action: "transform", text: help };
    }

    const match = text.match(/^#([\w-]+)\s+(.+)/s);
    if (match) {
      const agentName = match[1];
      const task = match[2].trim();
      const agents = discoverAgents(ctx.cwd);
      const found = agents.find((a) => a.name === agentName);
      if (found) {
        return {
          action: "transform",
          text: `用 agent 工具以 single 模式运行 ${agentName}，任务是：${task}`,
        };
      } else {
        const available = agents.map((a) => a.name).join(", ") || "(无)";
        if (ctx.hasUI) {
          ctx.ui.notify(`未知 agent: "${agentName}"。可用: ${available}`, "error");
          return { action: "handled" };
        }
        return { action: "transform", text: `未知 agent: "${agentName}"。可用: ${available}` };
      }
    }

    return { action: "continue" };
  });

  // ═══════════════════════════════════════════════════════════
  // /agent Command
  // ═══════════════════════════════════════════════════════════

  pi.registerCommand("agent", {
    description: "Manage agents: create / list / show / delete",
    handler: async (args, ctx) => {
      const parts = args.trim().split(/\s+/);
      const sub = parts[0]?.toLowerCase();

      // /agent list
      if (!sub || sub === "list") {
        const agents = discoverAgents(ctx.cwd);
        ctx.ui.notify(formatAgentList(agents), "info");
        return;
      }

      // /agent show <name>
      if (sub === "show") {
        const name = parts.slice(1).join(" ");
        if (!name) { ctx.ui.notify("Usage: /agent show <name>", "error"); return; }
        const agents = discoverAgents(ctx.cwd);
        const agent = agents.find((a) => a.name === name);
        if (!agent) { ctx.ui.notify(`Agent "${name}" not found.`, "error"); return; }
        const fg = ctx.ui.theme.fg.bind(ctx.ui.theme);
        const details = [
          `${fg("toolTitle", "name")}: ${fg("accent", agent.name)}`,
          `${fg("toolTitle", "desc")}: ${agent.description}`,
          `${fg("toolTitle", "type")}: ${agent.type || "standard"}`,
          agent.readonly ? `${fg("toolTitle", "mode")}: readonly` : "",
          agent.model ? `${fg("toolTitle", "model")}: ${agent.model}` : "",
          agent.tools ? `${fg("toolTitle", "tools")}: ${agent.tools.join(", ")}` : "",
          agent.disallowedTools ? `${fg("toolTitle", "deny")}: ${agent.disallowedTools.join(", ")}` : "",
          agent.maxTurns ? `${fg("toolTitle", "maxTurns")}: ${agent.maxTurns}` : "",
          agent.origin ? `${fg("toolTitle", "origin")}: ${agent.origin}` : "",
          agent.filePath ? `${fg("toolTitle", "file")}: ${agent.filePath}` : "",
          "",
          `${fg("toolTitle", "systemPrompt")}:`,
          agent.systemPrompt.slice(0, 1000),
        ].filter(Boolean).join("\n");
        ctx.ui.notify(details, "info");
        return;
      }

      // /agent delete <name>
      if (sub === "delete" || sub === "rm") {
        const name = parts.slice(1).join(" ");
        if (!name) { ctx.ui.notify("Usage: /agent delete <name>", "error"); return; }
        const result = removeAgentFiles(ctx.cwd, [name]);
        if (result.removed.length > 0) ctx.ui.notify(`Deleted agent "${name}".`, "info");
        else ctx.ui.notify(result.errors.join("; ") || `Agent "${name}" not found.`, "error");
        return;
      }

      // /agent create — interactive wizard
      if (sub === "create") {
        const name = await ctx.ui.input("🧑‍💼 Agent name:", "my-agent");
        if (!name) { ctx.ui.notify("Cancelled.", "info"); return; }

        const description = await ctx.ui.input("📝 Description:", "A helpful agent");
        if (!description) { ctx.ui.notify("Cancelled.", "info"); return; }

        const typeChoice = await ctx.ui.select("🎯 Type — how does it get context?", [
          "standard — Blank context, no history",
          "fork — Inherits recent conversation history",
          "team — Shares message board with other agents",
        ]);
        const type = typeChoice ? typeChoice.split(" — ")[0].trim() : "standard";

        // ── Permission settings ──
        const readonly = await ctx.ui.confirm("🔒 Read-only?", "Agent can only read files (not write or execute)") || false;

        let tools: string[] | undefined;
        let disallowedTools: string[] | undefined;
        if (!readonly) {
          const toolChoice = await ctx.ui.select("🛠️ Tool access?", [
            "All tools — No restrictions",
            "Allowlist — Only specific tools allowed",
            "Denylist — All tools except specific ones",
          ]);
          if ((toolChoice || "").startsWith("Allowlist")) {
            const toolsInput = await ctx.ui.input("✅ Allowed tools (comma-separated):", "read, write, bash");
            if (toolsInput) tools = toolsInput.split(",").map(t => t.trim()).filter(Boolean);
          } else if ((toolChoice || "").startsWith("Denylist")) {
            const denyInput = await ctx.ui.input("❌ Denied tools (comma-separated):", "write, edit");
            if (denyInput) disallowedTools = denyInput.split(",").map(t => t.trim()).filter(Boolean);
          }
        }

        const maxTurnsInput = await ctx.ui.input("🔄 Max turns (empty = unlimited):", "");
        const maxTurns = maxTurnsInput ? parseInt(maxTurnsInput, 10) : undefined;

        const modelChoice = await ctx.ui.select("🤖 Model:", [
          "inherit — Use parent session's model",
          "claude-sonnet-4-5 — Anthropic Sonnet (balanced)",
          "claude-haiku-4-5 — Anthropic Haiku (fast, cheap)",
          "claude-opus-4-5 — Anthropic Opus (most capable)",
          "other — Enter a custom model ID",
        ]);
        let model: string | undefined;
        if (modelChoice) {
          if (modelChoice.startsWith("inherit")) {
            model = undefined;
          } else if (modelChoice.startsWith("other")) {
            model = (await ctx.ui.input("Enter model ID (e.g. opencode-go/mimo-v2.5):", "")) || undefined;
          } else {
            model = modelChoice.split(" — ")[0].trim();
          }
        }

        // ── Scope ──
        const scopeChoice = await ctx.ui.select("📁 Agent scope:", [
          "project — Save to .pi/agents/ (project-local, recommended)",
          "global — Save to ~/.pi/agent/agents/ (shared across all projects)",
        ]);
        const isGlobal = (scopeChoice || "").startsWith("global");

        const defaultPrompt = `You are ${name}, ${description}. Execute the assigned task using your available tools.`;
        const systemPrompt = await ctx.ui.editor("📋 System prompt:", defaultPrompt);
        if (!systemPrompt) { ctx.ui.notify("Cancelled.", "info"); return; }

        const fg = ctx.ui.theme.fg.bind(ctx.ui.theme);
        const summaryLines = [
          `${fg("toolTitle", "Summary")}`,
          `  ${fg("accent", "name")}:        ${name}`,
          `  ${fg("accent", "desc")}:  ${description}`,
          `  ${fg("accent", "type")}:        ${type}`,
          `  ${fg("accent", "scope")}:      ${isGlobal ? "global" : "project"}`,
          readonly ? `  ${fg("accent", "mode")}:       readonly` : "  full access",
          tools ? `  ${fg("accent", "tools")}:       ${tools.join(", ")}` : "",
          disallowedTools ? `  ${fg("accent", "deny")}:        ${disallowedTools.join(", ")}` : "",
          maxTurns ? `  ${fg("accent", "maxTurns")}:    ${maxTurns}` : "",
          model ? `  ${fg("accent", "model")}:       ${model}` : "  (inherit)",
        ].filter(Boolean).join("\n");

        const confirmed = await ctx.ui.confirm(summaryLines, "Create this agent?");
        if (!confirmed) { ctx.ui.notify("Cancelled.", "info"); return; }

        const req: AgentCreateRequest = {
          name,
          description,
          systemPrompt,
          type: type as AgentType,
          readonly,
          tools,
          disallowedTools,
          maxTurns: maxTurns && maxTurns > 0 ? maxTurns : undefined,
          model,
          scope: isGlobal ? "global" : "project",
        };

        const result = createAgentFile(ctx.cwd, req);
        if (result.ok) {
          const location = isGlobal ? "~/.pi/agent/agents/" : ".pi/agents/";
          ctx.ui.notify(`✅ Agent "${name}" created in ${location}${name}.md\n\nTip: use #${name} to run it`, "success");
        } else {
          ctx.ui.notify(`❌ ${result.error}`, "error");
        }
        return;
      }

      // /agent status
      if (sub === "status") {
        if (parts[1] === "reset") {
          agentStatusMap.clear();
          agentSessions.length = 0;
          ctx.ui.notify("Agent status cleared.", "info");
          return;
        }
        const entries = [...agentStatusMap.values()];
        if (entries.length === 0 && agentSessions.length === 0) {
          ctx.ui.notify("No agent activity yet.", "info");
          return;
        }
        if (entries.length > 0) {
          const fg = ctx.ui.theme.fg.bind(ctx.ui.theme);
          ctx.ui.notify(renderDashboard(fg), "info");
        } else {
          const total = agentSessions.length;
          const running = agentSessions.filter((s) => s.status === "running").length;
          const done = agentSessions.filter((s) => s.status === "done").length;
          const failed = agentSessions.filter((s) => s.status === "failed").length;
          ctx.ui.notify(`Agent sessions: ${total} total, ${running} running, ${done} done, ${failed} failed`, "info");
        }
        return;
      }

      // /agent panel
      if (sub === "panel") {
        if (!ctx.hasUI) {
          ctx.ui.notify("Panel view requires TUI mode.", "info");
          return;
        }
        await ctx.ui.custom<void>((tui, theme, _keybindings, done) => {
          let selectedIndex = 0;
          const maxVisible = Math.max(5, tui.getSize().height - 8);

          const renderView = (): Text => {
            const visible = agentSessions.slice(0, 200);
            const total = visible.length;
            const startIdx = Math.max(0, Math.min(selectedIndex - Math.floor(maxVisible / 2), Math.max(0, total - maxVisible)));
            const displayItems = visible.slice(startIdx, startIdx + maxVisible);
            const lines: string[] = [];

            lines.push(theme.fg("toolTitle", theme.bold(" Agent View ")) + theme.fg("muted", ` [${total} sessions]`));
            lines.push(theme.fg("muted", " " + "─".repeat(Math.min(60, tui.getSize().width - 4))));

            for (let i = 0; i < displayItems.length; i++) {
              const s = displayItems[i];
              const idx = startIdx + i;
              const prefix = idx === selectedIndex ? theme.fg("accent", "▸ ") : "  ";
              const icon = s.status === "done" ? theme.fg("success", "✅")
                : s.status === "running" ? theme.fg("warning", "⏳")
                : s.status === "failed" ? theme.fg("error", "❌") : theme.fg("muted", "○");
              const elapsed = s.duration ? fmtDuration(s.duration) : s.startTime ? fmtDuration(Date.now() - s.startTime) : "--";
              const bgTag = s.background ? theme.fg("warning", " [BG]") : "";
              const name = s.agentName.length > 14 ? s.agentName.slice(0, 12) + ".." : s.agentName.padEnd(14);
              lines.push(`${prefix}${icon} ${theme.fg("accent", name)}${bgTag} ${theme.fg("muted", elapsed.padStart(7))}  ${theme.fg("dim", s.task.slice(0, Math.min(40, tui.getSize().width - 50)))}`);
            }
            if (total === 0) lines.push(theme.fg("muted", "  No sessions yet."));
            lines.push("");
            lines.push(theme.fg("muted", " ↑↓ Navigate  |  Enter Peek  |  Q Quit"));
            return new Text(lines.join("\n"), 0, 0);
          };

          const comp = renderView();
          comp.onKey = (key: string) => {
            if (key === "q" || key === "escape") { done(undefined); return true; }
            if (key === "up") { selectedIndex = Math.max(0, selectedIndex - 1); comp.setText(renderView().getText()); return true; }
            if (key === "down") { selectedIndex = Math.min(agentSessions.length - 1, selectedIndex + 1); comp.setText(renderView().getText()); return true; }
            if (key === "return") {
              const s = agentSessions[selectedIndex];
              if (s && s.output) {
                done(undefined);
                setTimeout(() => ctx.ui.notify(`### ${s.agentName} (${s.status})\n\n${s.output.slice(0, 2000)}`, "info"), 50);
              } else if (s && s.error) {
                done(undefined);
                setTimeout(() => ctx.ui.notify(`### ${s.agentName} — Error\n\n${s.error}`, "error"), 50);
              }
              return true;
            }
            return false;
          };
          return comp;
        });
        return;
      }

      // Unknown subcommand
      ctx.ui.notify([
        "Usage: /agent <subcommand>",
        "  /agent create    — interactive wizard",
        "  /agent list      — list all agents",
        "  /agent show <n>  — show agent details",
        "  /agent status    — show execution dashboard",
        "  /agent panel     — open TUI agent view",
        "  /agent delete <n>— delete an agent",
        "",
        "Tip: just tell the AI in plain language to create an agent!",
        '     "帮我创建一个fork类型的文献综述agent"',
      ].join("\n"), "info");
    },
  });

  // ── /agents Command (shortcut) ──
  pi.registerCommand("agents", {
    description: "List all available agents",
    handler: async (_args, ctx) => {
      const agents = discoverAgents(ctx.cwd);
      ctx.ui.notify(formatAgentList(agents), "info");
    },
  });

  // ═══════════════════════════════════════════════════════════
  // Tool 1: create_agents
  // ═══════════════════════════════════════════════════════════

  pi.registerTool({
    name: "create_agents",
    label: "Create Agents",
    description: [
      "Create project-local agent definitions in .pi/agents/.",
      "Use this when a complex task would benefit from multiple specialized agents.",
      "Each agent gets its own .md file with YAML frontmatter.",
      "Agents can then be invoked via the 'agent' tool.",
    ].join(" "),
    promptSnippet: "Create project-local agent definitions",
    promptGuidelines: [
      "Use create_agents when a task is complex enough to benefit from specialized sub-agents. Always create all agents in a single call.",
      "Design each agent with a clear, single responsibility.",
      "Use readonly: true for agents that only need to read files (simplest option).",
      "Use type: 'fork' to create agents that inherit session history.",
      "Use type: 'team' for agents that communicate with siblings via shared message board.",
      "Use cheaper models for read-only exploration agents; use full models for writing/editing agents.",
      "For agents based on skill files: use a reference-style systemPrompt rather than copying the full content. Use absolute paths.",
      "For agents designed from scratch: write the complete systemPrompt directly.",
    ],
    parameters: Type.Object({
      agents: Type.Array(
        Type.Object({
          name: Type.String({ description: "Unique agent name (lowercase, hyphens allowed)" }),
          description: Type.String({ description: "What this agent does (shown in listings)" }),
          systemPrompt: Type.String({ description: "Full system prompt / instructions for the agent" }),
          type: Type.Optional(
            StringEnum(["standard", "fork", "team"] as const, {
              description: '"standard" (blank context), "fork" (inherits session history), or "team" (communicates with siblings). Default: "standard".',
            }),
          ),
          readonly: Type.Optional(
            Type.Boolean({ description: "Read-only mode: agent can only read files. Default: full access." }),
          ),
          disallowedTools: Type.Optional(
            Type.Array(Type.String(), { description: "Tools to deny, removed from the agent's available tools. Use when you want all tools except specific ones (e.g. [\"write\", \"edit\"])." }),
          ),
          model: Type.Optional(
            Type.String({
              description: "Model for this agent (e.g. claude-haiku-4-5, claude-sonnet-4-5). Default: inherit from parent.",
            }),
          ),
          maxTurns: Type.Optional(
            Type.Number({ description: "Maximum agentic turns before the agent stops. Prevents infinite loops. Default: unlimited." }),
          ),
        }),
        { description: "Agent definitions to create" },
      ),
    }),

    async execute(_id, params, _signal, _onUpdate, ctx) {
      const reqs: AgentCreateRequest[] = (params.agents as any[]).map((a: any) => ({
        ...a,
        type: a.type || "standard",
        readonly: a.readonly === true,
      }));

      const created: string[] = [];
      const errors: string[] = [];

      for (const req of reqs) {
        const result = createAgentFile(ctx.cwd, req);
        if (result.ok) {
          created.push(req.name);
        } else {
          errors.push(`${req.name}: ${result.error}`);
        }
      }

      const parts: string[] = [];
      if (created.length > 0) {
        parts.push(`Created ${created.length} agent(s) in .pi/agents/: ${created.join(", ")}`);
      }
      if (errors.length > 0) {
        parts.push(`Errors: ${errors.join("; ")}`);
      }

      return {
        content: [{ type: "text" as const, text: parts.join("\n\n") || "No agents created." }],
        details: { created, errors },
      };
    },

    renderCall(args, theme, _ctx) {
      const agents = (args.agents || []) as any[];
      let text =
        theme.fg("toolTitle", theme.bold("create_agents ")) +
        theme.fg("accent", `${agents.length} agent(s)`);
      for (const a of agents) {
        const typeTag = a.type && a.type !== "standard" ? theme.fg("warning", ` [${a.type}]`) : "";
        const roTag = a.readonly ? theme.fg("muted", " [readonly]") : "";
        const model = a.model ? theme.fg("warning", ` @${a.model}`) : "";
        text += `\n  ${theme.fg("success", "+")} ${theme.fg("accent", a.name)}${typeTag}${roTag}${model}`;
        text += `\n    ${theme.fg("muted", (a.description || "").slice(0, 60))}`;
      }
      text += `\n  ${theme.fg("dim", `→ .pi/agents/`)}`;
      return new Text(text, 0, 0);
    },

    renderResult(result, _opts, theme, _ctx) {
      const d = result.details as { created?: string[]; errors?: string[] } | undefined;
      let text = "";
      if (d?.created?.length) {
        text += theme.fg("success", `✓ Created: ${d.created.join(", ")}`);
      }
      if (d?.errors?.length) {
        if (text) text += "\n";
        text += theme.fg("error", `✗ ${d.errors.join("; ")}`);
      }
      if (!text) text = theme.fg("muted", "No agents created.");
      return new Text(text, 0, 0);
    },
  });

  // ═══════════════════════════════════════════════════════════
  // Tool 2: cleanup_agents
  // ═══════════════════════════════════════════════════════════

  pi.registerTool({
    name: "cleanup_agents",
    label: "Cleanup Agents",
    description: [
      "Remove project-local agent files from .pi/agents/.",
      "Use this after a multi-agent workflow completes to clean up temporary agents.",
      "Specify names to remove specific agents, or all: true to remove all project agents.",
      "Global agents (~/.pi/agent/agents/) are never affected.",
    ].join(" "),
    promptSnippet: "Remove project-local agent definitions",
    parameters: Type.Object({
      agents: Type.Optional(
        Type.Array(Type.String(), { description: "Agent names to remove" }),
      ),
      all: Type.Optional(
        Type.Boolean({ description: "Remove ALL project agents. Default: false.", default: false }),
      ),
    }),

    async execute(_id, params, _signal, _onUpdate, ctx) {
      let removed: string[] = [];
      let errors: string[] = [];

      if (params.all) {
        const r = removeAllProjectAgents(ctx.cwd);
        removed = r.removed;
        errors = r.errors;
      } else if (params.agents?.length) {
        const r = removeAgentFiles(ctx.cwd, params.agents);
        removed = r.removed;
        errors = r.errors;
      } else {
        return {
          content: [{ type: "text" as const, text: "Specify agent names or all: true." }],
          details: {},
        };
      }

      const parts: string[] = [];
      if (removed.length) parts.push(`Removed: ${removed.join(", ")}`);
      if (errors.length) parts.push(`Errors: ${errors.join("; ")}`);

      return {
        content: [{ type: "text" as const, text: parts.join("\n") || "Nothing removed." }],
        details: { removed, errors },
      };
    },

    renderCall(args, theme, _ctx) {
      const names = args.all ? "all" : (args.agents as string[])?.join(", ") || "...";
      return new Text(theme.fg("toolTitle", theme.bold("cleanup_agents ")) + theme.fg("warning", names), 0, 0);
    },

    renderResult(result, _opts, theme, _ctx) {
      const d = result.details as { removed?: string[]; errors?: string[] } | undefined;
      let text = "";
      if (d?.removed?.length) text += theme.fg("success", `✓ Removed: ${d.removed.join(", ")}`);
      if (d?.errors?.length) {
        if (text) text += "\n";
        text += theme.fg("error", `✗ ${d.errors.join("; ")}`);
      }
      return new Text(text || theme.fg("muted", "Nothing removed."), 0, 0);
    },
  });

  // ═══════════════════════════════════════════════════════════
  // Tool 3: agent
  // ═══════════════════════════════════════════════════════════

  pi.registerTool({
    name: "agent",
    label: "Agent",
    description: [
      "Delegate tasks to agents. Agents are discovered from .pi/agents/ (project),",
      "~/.pi/agent/agents/ (global), or defined inline.",
      "Modes: single (agent+task), parallel (tasks array), chain (sequential with {previous}),",
      "team (parallel with shared message board for inter-agent communication).",
      "Use create_agents to create project agents first. Use /agents to list available agents.",
    ].join(" "),
    promptSnippet: "Delegate a task to a specialized agent",
    promptGuidelines: [
      "Use agent to delegate complex subtasks to specialized agents with isolated context.",
      "For multi-step workflows, use chain mode with {previous} to pass output between steps.",
      "Use team mode for collaborative tasks: agents share a temp directory to read/write intermediate results.",
      "After a multi-agent workflow completes, consider calling cleanup_agents to remove temporary project agents.",
    ],
    parameters: Type.Object({
      agent: Type.Optional(
        Type.Union([
          Type.String({ description: "Agent name (from registry)" }),
          Type.Object(
            {
              name: Type.Optional(Type.String()),
              systemPrompt: Type.String({ description: "System prompt for inline agent" }),
              description: Type.Optional(Type.String()),
              tools: Type.Optional(Type.Array(Type.String())),
              model: Type.Optional(Type.String()),
            },
            { description: "Inline agent definition (no file created)" },
          ),
        ]),
      ),
      task: Type.Optional(Type.String()),
      parallel: Type.Optional(
        Type.Array(
          Type.Object({
            agent: Type.Union([Type.String(), Type.Object({ systemPrompt: Type.String() }, { additionalProperties: true })]),
            task: Type.String(),
            produces: Type.Optional(Type.Array(Type.String())),
            cwd: Type.Optional(Type.String()),
          }),
        ),
      ),
      chain: Type.Optional(
        Type.Array(
          Type.Object({
            agent: Type.Union([Type.String(), Type.Object({ systemPrompt: Type.String() }, { additionalProperties: true })]),
            task: Type.String({ description: "Task. Use {previous} for prior step output." }),
            produces: Type.Optional(Type.Array(Type.String())),
            cwd: Type.Optional(Type.String()),
          }),
        ),
      ),
      team: Type.Optional(
        Type.Array(
          Type.Object({
            agent: Type.Union([Type.String(), Type.Object({ systemPrompt: Type.String() }, { additionalProperties: true })]),
            task: Type.String(),
            produces: Type.Optional(Type.Array(Type.String())),
            cwd: Type.Optional(Type.String()),
          }),
        ),
      ),
      background: Type.Optional(
        Type.Boolean({ description: "Run in background (non-blocking). You'll be notified when complete. Default: false." }),
      ),
      produces: Type.Optional(Type.Array(Type.String())),
      cwd: Type.Optional(Type.String()),
      timeout: Type.Optional(Type.Number({ description: "Timeout in ms per agent spawn (default: 300000 = 5 min). 0 = no timeout." })),
    }),

    async execute(_id, params, signal, _onUpdate, ctx) {
      const agents = discoverAgents(ctx.cwd);
      const branchEntries = ctx.sessionManager.getBranch();
      const forkCtx = collectForkContext(branchEntries as any);

      const hasChain = (params.chain?.length ?? 0) > 0;
      const hasPar = (params.parallel?.length ?? 0) > 0;
      const hasTeam = (params.team?.length ?? 0) > 0;
      const hasSingle = !!(params.agent && params.task);
      const count = Number(hasChain) + Number(hasPar) + Number(hasTeam) + Number(hasSingle);

      // ── TUI feedback helpers ──
      const hideStatus = () => {
        if (ctx.hasUI) ctx.ui.setStatus("agent-running", undefined);
      };

      if (count !== 1) {
        return {
          content: [{ type: "text" as const, text: `Provide exactly one mode (agent+task, parallel, chain, or team).\n\n${formatAgentList(agents)}` }],
          details: { mode: "single" as const, results: [], totalUsage: emptyUsage() },
        };
      }

      // ── Dispatch to execution mode ──

      if (hasChain && params.chain) {
        return await executeChainMode(params.chain, ctx, signal, forkCtx, agents);
      }

      if (hasPar && params.parallel) {
        return await executeParallelMode(params.parallel, ctx, signal, forkCtx, agents);
      }

      if (hasTeam && params.team) {
        return await executeTeamMode(params.team, ctx, signal, forkCtx, agents);
      }

      if (hasSingle && params.agent && params.task) {
        const agentName = typeof params.agent === "string" ? params.agent : (params.agent as any)?.name || "inline";

        // Background mode
        if (params.background) {
          const session = addSession({ agentName, task: params.task as string, mode: "single" as const, status: "running", background: true });

          executeSingleMode(params.agent, params.task, ctx, signal, params.produces, params.cwd, forkCtx)
            .then((result) => {
              const ok = !result.isError;
              const output = result.content[0]?.text || "";
              updateSession(session.id, {
                status: ok ? "done" : "failed",
                endTime: Date.now(),
                duration: Date.now() - session.startTime,
                output,
                error: ok ? undefined : output,
              });
              try {
                pi.sendUserMessage(`[Background] ${ok ? "✅" : "❌"} Agent "${agentName}" ${ok ? "completed" : "failed"} (${fmtDuration(Date.now() - session.startTime)})\n\n${output.slice(0, SESSION_TEXT_CAP)}${output.length > SESSION_TEXT_CAP ? "\n\n[Output truncated...]" : ""}`, { deliverAs: "followUp" });
              } catch { /* session may have ended */ }
            })
            .catch((err) => {
              updateSession(session.id, { status: "failed", endTime: Date.now(), duration: Date.now() - session.startTime, error: err.message });
              try {
                pi.sendUserMessage(`[Background] ❌ Agent "${agentName}" failed: ${err.message}`, { deliverAs: "followUp" });
              } catch { /* session may have ended */ }
            });

          return {
            content: [{ type: "text" as const, text: `⏳ Background agent "${agentName}" started. You'll be notified when it completes. Check /agent panel for status.` }],
            details: { mode: "single" as const, results: [], totalUsage: emptyUsage() },
          };
        }

        return await executeSingleMode(params.agent, params.task, ctx, signal, params.produces, params.cwd, forkCtx);
      }

      // Should never reach here (count !== 1 handled above)
      return {
        content: [{ type: "text" as const, text: "No valid execution mode specified." }],
        details: { mode: "single" as const, results: [], totalUsage: emptyUsage() },
      };
    },

    // ── TUI: renderCall ──

    renderCall(args, theme, _ctx) {
      // Chain
      if (args.chain?.length) {
        let t =
          theme.fg("toolTitle", theme.bold("agent ")) +
          theme.fg("accent", `chain (${args.chain.length} steps)`);
        for (let i = 0; i < Math.min(args.chain.length, 3); i++) {
          const s = args.chain[i];
          const a = typeof s.agent === "string" ? s.agent : s.agent?.name || "inline";
          const task = (s.task || "").replace(/\{previous\}/g, "").trim();
          const preview = task.length > 40 ? task.slice(0, 40) + "..." : task;
          t += `\n  ${theme.fg("muted", `${i + 1}.`)} ${theme.fg("accent", a)}${theme.fg("dim", ` ${preview}`)}`;
        }
        if (args.chain.length > 3) t += `\n  ${theme.fg("muted", `... +${args.chain.length - 3} more`)}`;
        return new Text(t, 0, 0);
      }

      // Team
      if (args.team?.length) {
        let t =
          theme.fg("toolTitle", theme.bold("agent ")) +
          theme.fg("warning", `team (${args.team.length} members)`);
        for (const s of (args.team as any[]).slice(0, 3)) {
          const a = typeof s.agent === "string" ? s.agent : s.agent?.name || "inline";
          const preview = (s.task || "").length > 40 ? s.task.slice(0, 40) + "..." : s.task;
          t += `\n  ${theme.fg("accent", a)}${theme.fg("dim", ` ${preview}`)}`;
        }
        if (args.team.length > 3) t += `\n  ${theme.fg("muted", `... +${args.team.length - 3} more`)}`;
        return new Text(t, 0, 0);
      }

      // Parallel
      if (args.parallel?.length) {
        let t =
          theme.fg("toolTitle", theme.bold("agent ")) +
          theme.fg("accent", `parallel (${args.parallel.length} tasks)`);
        for (const s of (args.parallel as any[]).slice(0, 3)) {
          const a = typeof s.agent === "string" ? s.agent : s.agent?.name || "inline";
          const preview = (s.task || "").length > 40 ? s.task.slice(0, 40) + "..." : s.task;
          t += `\n  ${theme.fg("accent", a)}${theme.fg("dim", ` ${preview}`)}`;
        }
        if (args.parallel.length > 3) t += `\n  ${theme.fg("muted", `... +${args.parallel.length - 3} more`)}`;
        return new Text(t, 0, 0);
      }

      // Single
      const a = typeof args.agent === "string" ? args.agent : args.agent?.name || "inline";
      const preview = args.task ? (args.task.length > 80 ? args.task.slice(0, 80) + "..." : args.task) : "...";
      let t = theme.fg("toolTitle", theme.bold("agent ")) + theme.fg("accent", a);
      t += `\n  ${theme.fg("dim", preview)}`;
      return new Text(t, 0, 0);
    },

    // ── TUI: renderResult ──

    renderResult(result, { expanded }, theme, _ctx) {
      const details = result.details as AgentToolDetail | undefined;
      if (!details || details.results.length === 0) {
        const t = result.content[0];
        return new Text(t?.type === "text" ? t.text : "(no output)", 0, 0);
      }

      const mdTheme = getMarkdownTheme();

      const renderItems = (items: DisplayItem[], limit?: number): string => {
        const show = limit ? items.slice(-limit) : items;
        const skipped = limit && items.length > limit ? items.length - limit : 0;
        let t = "";
        if (skipped > 0) t += theme.fg("muted", `... ${skipped} earlier items\n`);
        for (const item of show) {
          if (item.type === "text") {
            const preview = expanded ? item.text : item.text.split("\n").slice(0, 3).join("\n");
            t += `${theme.fg("toolOutput", preview)}\n`;
          } else {
            t += `${theme.fg("muted", "→ ") + fmtTool(item.name, item.args, theme.fg.bind(theme))}\n`;
          }
        }
        return t.trimEnd();
      };

      // ── Single ──
      if (details.mode === "single" && details.results.length === 1) {
        const r = details.results[0];
        const err = isFailed(r);
        const icon = err ? theme.fg("error", "✗") : theme.fg("success", "✓");
        const items = displayItems(r.messages);
        const final = getFinal(r.messages);

        if (expanded) {
          const c = new Container();
          let h = `${icon} ${theme.fg("toolTitle", theme.bold(r.agent))}${theme.fg("muted", ` (${r.origin})`)}`;
          if (err && r.stopReason) h += ` ${theme.fg("error", `[${r.stopReason}]`)}`;
          c.addChild(new Text(h, 0, 0));
          if (err && r.errorMessage) c.addChild(new Text(theme.fg("error", `Error: ${r.errorMessage}`), 0, 0));

          c.addChild(new Spacer(1));
          c.addChild(new Text(theme.fg("muted", "─── Task ───"), 0, 0));
          c.addChild(new Text(theme.fg("dim", r.task.length > 300 ? r.task.slice(0, 300) + "..." : r.task), 0, 0));
          c.addChild(new Spacer(1));
          c.addChild(new Text(theme.fg("muted", "─── Output ───"), 0, 0));

          if (items.length === 0 && !final) c.addChild(new Text(theme.fg("muted", "(no output)"), 0, 0));
          else {
            for (const item of items) {
              if (item.type === "toolCall") {
                c.addChild(new Text(theme.fg("muted", "→ ") + fmtTool(item.name, item.args, theme.fg.bind(theme)), 0, 0));
              }
            }
            if (final) {
              c.addChild(new Spacer(1));
              c.addChild(new Markdown(final.trim(), 0, 0, mdTheme));
            }
          }

          const u = fmtUsage(r.usage, r.model);
          if (u) { c.addChild(new Spacer(1)); c.addChild(new Text(theme.fg("dim", u), 0, 0)); }
          if (r.filesProduced.length) c.addChild(new Text(theme.fg("success", `✓ Files: ${r.filesProduced.join(", ")}`), 0, 0));
          return c;
        }

        let t = `${icon} ${theme.fg("toolTitle", theme.bold(r.agent))}${theme.fg("muted", ` (${r.origin})`)}`;
        if (err && r.stopReason) t += ` ${theme.fg("error", `[${r.stopReason}]`)}`;
        if (err && r.errorMessage) t += `\n${theme.fg("error", `Error: ${r.errorMessage}`)}`;
        else if (items.length === 0) t += `\n${theme.fg("muted", "(no output)")}`;
        else {
          t += `\n${renderItems(items, COLLAPSED_ITEMS)}`;
          if (items.length > COLLAPSED_ITEMS) t += `\n${theme.fg("muted", "(Ctrl+O to expand)")}`;
        }
        const u = fmtUsage(r.usage, r.model);
        if (u) t += `\n${theme.fg("dim", u)}`;
        return new Text(t, 0, 0);
      }

      // ── Chain ──
      if (details.mode === "chain") {
        const ok = details.results.filter((r) => r.exitCode === 0).length;
        const icon = ok === details.results.length ? theme.fg("success", "✓") : theme.fg("error", "✗");

        if (expanded) {
          const c = new Container();
          c.addChild(new Text(`${icon} ${theme.fg("toolTitle", theme.bold("chain "))}${theme.fg("accent", `${ok}/${details.results.length} steps`)}`, 0, 0));
          for (const r of details.results) {
            const ri = r.exitCode === 0 ? theme.fg("success", "✓") : theme.fg("error", "✗");
            const items = displayItems(r.messages);
            const final = getFinal(r.messages);
            c.addChild(new Spacer(1));
            c.addChild(new Text(`${theme.fg("muted", `─── Step ${r.step}: `)}${theme.fg("accent", r.agent)} ${ri}`, 0, 0));
            c.addChild(new Text(theme.fg("muted", "Task: ") + theme.fg("dim", r.task.length > 150 ? r.task.slice(0, 150) + "..." : r.task), 0, 0));
            for (const item of items) {
              if (item.type === "toolCall") c.addChild(new Text(theme.fg("muted", "→ ") + fmtTool(item.name, item.args, theme.fg.bind(theme)), 0, 0));
            }
            if (final) { c.addChild(new Spacer(1)); c.addChild(new Markdown(final.trim(), 0, 0, mdTheme)); }
            const su = fmtUsage(r.usage, r.model);
            if (su) c.addChild(new Text(theme.fg("dim", su), 0, 0));
          }
          const tu = fmtUsage(details.totalUsage);
          if (tu) { c.addChild(new Spacer(1)); c.addChild(new Text(theme.fg("dim", `Total: ${tu}`), 0, 0)); }
          return c;
        }

        let t = `${icon} ${theme.fg("toolTitle", theme.bold("chain "))}${theme.fg("accent", `${ok}/${details.results.length} steps`)}`;
        for (const r of details.results) {
          const ri = r.exitCode === 0 ? theme.fg("success", "✓") : theme.fg("error", "✗");
          const items = displayItems(r.messages);
          t += `\n\n${theme.fg("muted", `─── Step ${r.step}: `)}${theme.fg("accent", r.agent)} ${ri}`;
          if (items.length === 0) t += `\n${theme.fg("muted", "(no output)")}`;
          else t += `\n${renderItems(items, 5)}`;
        }
        const tu = fmtUsage(details.totalUsage);
        if (tu) t += `\n\n${theme.fg("dim", `Total: ${tu}`)}`;
        t += `\n${theme.fg("muted", "(Ctrl+O to expand)")}`;
        return new Text(t, 0, 0);
      }

      // ── Parallel ──
      if (details.mode === "parallel") {
        const running = details.results.filter((r) => r.exitCode === -1).length;
        const ok = details.results.filter((r) => r.exitCode !== -1 && !isFailed(r)).length;
        const fail = details.results.filter((r) => r.exitCode !== -1 && isFailed(r)).length;
        const isRun = running > 0;
        const icon = isRun ? theme.fg("warning", "⏳") : fail > 0 ? theme.fg("warning", "◐") : theme.fg("success", "✓");
        const status = isRun ? `${ok + fail}/${details.results.length} done, ${running} running` : `${ok}/${details.results.length} tasks`;

        if (expanded && !isRun) {
          const c = new Container();
          c.addChild(new Text(`${icon} ${theme.fg("toolTitle", theme.bold("parallel "))}${theme.fg("accent", status)}`, 0, 0));
          for (const r of details.results) {
            const ri = isFailed(r) ? theme.fg("error", "✗") : theme.fg("success", "✓");
            const items = displayItems(r.messages);
            const final = getFinal(r.messages);
            c.addChild(new Spacer(1));
            c.addChild(new Text(`${theme.fg("muted", "─── ")}${theme.fg("accent", r.agent)} ${ri}`, 0, 0));
            c.addChild(new Text(theme.fg("muted", "Task: ") + theme.fg("dim", r.task.length > 150 ? r.task.slice(0, 150) + "..." : r.task), 0, 0));
            for (const item of items) {
              if (item.type === "toolCall") c.addChild(new Text(theme.fg("muted", "→ ") + fmtTool(item.name, item.args, theme.fg.bind(theme)), 0, 0));
            }
            if (final) { c.addChild(new Spacer(1)); c.addChild(new Markdown(final.trim(), 0, 0, mdTheme)); }
            const su = fmtUsage(r.usage, r.model);
            if (su) c.addChild(new Text(theme.fg("dim", su), 0, 0));
          }
          const tu = fmtUsage(details.totalUsage);
          if (tu) { c.addChild(new Spacer(1)); c.addChild(new Text(theme.fg("dim", `Total: ${tu}`), 0, 0)); }
          return c;
        }

        let t = `${icon} ${theme.fg("toolTitle", theme.bold("parallel "))}${theme.fg("accent", status)}`;
        for (const r of details.results) {
          const ri = r.exitCode === -1 ? theme.fg("warning", "⏳") : isFailed(r) ? theme.fg("error", "✗") : theme.fg("success", "✓");
          const items = displayItems(r.messages);
          t += `\n\n${theme.fg("muted", "─── ")}${theme.fg("accent", r.agent)} ${ri}`;
          if (items.length === 0) t += `\n${theme.fg("muted", r.exitCode === -1 ? "(running...)" : "(no output)")}`;
          else t += `\n${renderItems(items, 5)}`;
        }
        if (!isRun) {
          const tu = fmtUsage(details.totalUsage);
          if (tu) t += `\n\n${theme.fg("dim", `Total: ${tu}`)}`;
          t += `\n${theme.fg("muted", "(Ctrl+O to expand)")}`;
        }
        return new Text(t, 0, 0);
      }

      // ── Team ──
      if (details.mode === "team") {
        const ok = details.results.filter((r) => !isFailed(r)).length;
        const icon = ok === details.results.length ? theme.fg("success", "✓") : theme.fg("warning", "◐");
        let t = `${icon} ${theme.fg("toolTitle", theme.bold("team "))}${theme.fg("accent", `${ok}/${details.results.length} members`)}`;
        for (const r of details.results) {
          const ri = isFailed(r) ? theme.fg("error", "✗") : theme.fg("success", "✓");
          const items = displayItems(r.messages);
          t += `\n\n${theme.fg("muted", "─── ")}${theme.fg("accent", r.agent)} ${ri}`;
          if (items.length === 0) t += `\n${theme.fg("muted", "(no output)")}`;
          else t += `\n${renderItems(items, 5)}`;
        }
        const tu = fmtUsage(details.totalUsage);
        if (tu) t += `\n\n${theme.fg("dim", `Total: ${tu}`)}`;
        return new Text(t, 0, 0);
      }

      const txt = result.content[0];
      return new Text(txt?.type === "text" ? txt.text : "(no output)", 0, 0);
    },
  });
}