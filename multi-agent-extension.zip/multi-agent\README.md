# Multi-Agent Extension for Pi

创建、运行和管理多个 AI 智能体的 Pi 扩展。支持三种智能体类型、四种执行模式、嵌套调用和完整生命周期管理。

对比 Claude Code 的子智能体系统，本扩展额外提供：**按工具名精确权限控制、多模型编排、智能体文件持久化、进程级隔离**。

---

## 目录

- [核心工具](#核心工具)
- [智能体类型](#智能体类型)
- [执行模式](#执行模式)
- [生命周期管理](#生命周期管理)
- [嵌套调用](#嵌套调用)
- [快速上手](#快速上手)
- [实战教程：从零写一篇经济学论文](#实战教程从零写一篇经济学论文)
- [最佳实践](#最佳实践)
- [配置参考](#配置参考)

---

## 核心工具

扩展注册了三个 LLM 可调用的工具：

| 工具 | 功能 | 生命周期阶段 |
|------|------|-------------|
| `create_agents` | 创建智能体定义，写入 `.pi/agents/*.md` | 出生 |
| `agent` | 执行智能体任务（single/parallel/chain/team） | 工作 |
| `cleanup_agents` | 删除智能体文件 | 销毁 |

---

## 智能体类型

创建智能体时可通过 `type` 字段指定类型：

### standard（默认）
- **空白上下文启动**，不继承主会话历史
- 适用于独立简单任务：摘要、提取、计算
- 对应 Claude Code: Standard Subagent

### fork
- **继承主会话上下文**：自动收集最近 20 轮对话和文件引用，注入 system prompt
- 子智能体"知道"前面讨论了什么
- 适用于需要上下文的复杂任务：代码重构、方案迭代
- 对应 Claude Code: Fork Subagent

### team
- 通过**共享文件系统消息板**与其他 team 成员通信
- 每个成员可写入/读取 `{teamDir}/{name}-result.json`
- 适用于协作式任务：多文件并行审查、多维度分析
- 对应 Claude Code: Team Subagent

示例：
```yaml
---
name: paper-reviewer
description: 论文审稿专家
type: fork
tools: read, write
model: claude-sonnet-4-5
---
你是一位资深经济学审稿人……
```

---

## 执行模式

### Single — 单智能体执行

```typescript
agent({
  agent: "data-analyzer",
  task: "分析这份数据并生成报告"
})
```

### Parallel — 并行执行

多个独立任务同时运行：

```typescript
agent({
  parallel: [
    { agent: "reviewer", task: "审查章节1" },
    { agent: "reviewer", task: "审查章节2" },
    { agent: "reviewer", task: "审查章节3" }
  ]
})
```

### Chain — 链式执行

顺序执行，前一步的输出通过 `{previous}` 传递给下一步：

```typescript
agent({
  chain: [
    { agent: "extractor", task: "从文献中提取关键数据" },
    { agent: "analyzer", task: "分析以下数据：\n{previous}" },
    { agent: "writer", task: "基于分析撰写报告：\n{previous}" }
  ]
})
```

### Team — 团队协作执行

多个 agent 通过共享目录交流中间结果：

```typescript
agent({
  team: [
    { agent: "fe-reviewer", task: "审查前端代码，结果写入共享目录" },
    { agent: "be-reviewer", task: "审查后端代码，结果写入共享目录" },
    { agent: "summarizer", task: "读取共享目录中所有人的结果，输出汇总报告" }
  ]
})
```

---

## 生命周期管理

```
create_agents ──►  agent  ──►  cleanup_agents
  （出生）        （工作）        （销毁）
     │               │              │
  写 .md 文件     运行调度       删 .md 文件
  跨 session 保留  状态追踪      不留文件残留
  可复用           四种模式      选择性或批量
```

与 Claude Code 的关键区别：

| | Claude Code | 你的扩展 |
|--|-------------|---------|
| 智能体存储 | 运行时内存，会话结束即消失 | `.pi/agents/*.md` 文件持久化 |
| 跨会话复用 | ❌ 每次重新定义 | ✅ 定义一次，反复调用 |
| 显式清理 | ❌ 无需清理 | ✅ `cleanup_agents` 主动管理 |
| 分享 | ❌ | ✅ 分享 `.md` 文件即可 |

---

## 嵌套调用

子智能体可以再创建和运行子智能体，最多 3 层：

```
主 agent ──► 子 agent ──► 孙 agent
depth=0      depth=1      depth=2
```

通过 `PI_AGENT_DEPTH` 环境变量追踪深度，超过 3 层自动停止。子 agent 需要在其 `tools` 中包含 `create_agents` 和 `agent` 才能嵌套。

---

## 快速上手

### 安装

已在 `~/.pi/agent/extensions/multi-agent/` 中，pi 会自动发现。

### 第一步：创建一个 agent

在 pi 中直接说：
```
帮我创建一个叫文献搜索的 agent，类型是 fork，工具用 read 和 bash，
系统提示词是"你是一位经济学文献搜索专家，擅长在 OpenAlex 中查找相关研究"
```

### 第二步：运行它

```
用 agent 工具 single 模式运行文献搜索 agent，
任务是"搜索最近5年关于断点回归的论文"
```

### 第三步：用完清理

```
用 cleanup_agents 工具删除文献搜索 agent
```

---

## 完整实战教程：从零写一篇经济学论文

假设你要写一篇题为"最低工资对就业的影响：基于断点回归的新证据"的论文。以下是使用 Multi-Agent Extension 的完整工作流。

### 第 1 步：创建你的"论文工厂"团队

```typescript
create_agents([
  {
    name: "lit-reviewer",
    description: "文献综述专家",
    type: "fork",
    tools: ["read", "bash", "write"],
    model: "opencode-go/mimo-v2.5",
    systemPrompt: "你是一位经济学文献综述专家。你的任务是：\n- 搜索指定主题的学术文献\n- 总结每篇文献的核心发现、方法和数据\n- 按主题组织文献，指出研究空白\n- 输出结构化的文献综述"
  },
  {
    name: "data-analyst",
    description: "数据分析师",
    type: "fork",
    tools: ["read", "bash", "write"],
    model: "opencode-go/mimo-v2.5",
    systemPrompt: "你是一位计量经济学数据分析师。你的任务是：\n- 描述数据集结构和关键变量\n- 执行描述性统计分析\n- 运行断点回归（RDD）模型\n- 解释回归结果\n- 输出 LaTeX 格式的回归表格"
  },
  {
    name: "method-expert",
    description: "计量方法专家",
    type: "fork",
    tools: ["read", "bash", "write"],
    model: "opencode-go/mimo-v2.5",
    systemPrompt: "你是一位计量经济学方法论专家。你的任务是：\n- 评估研究设计的识别策略\n- 检查断点回归的有效性条件\n- 建议稳健性检验方法\n- 评估内生性威胁\n- 输出方法学评估报告"
  },
  {
    name: "paper-writer",
    description: "论文撰写专家",
    type: "fork",
    tools: ["read", "bash", "write"],
    model: "opencode-go/mimo-v2.5",
    systemPrompt: "你是一位经济学论文撰写专家。你的任务是：\n- 按照经济学顶刊标准撰写论文各部分\n- 输出 LaTeX 格式\n- 确保逻辑连贯、论证严密\n- 包含引言、文献综述、研究方法、实证结果、结论"
  },
  {
    name: "referee",
    description: "审稿专家",
    type: "fork",
    tools: ["read", "write"],
    model: "opencode-go/mimo-v2.5",
    systemPrompt: "你是一位严格的学术审稿人。你的任务是：\n- 批判性评估论文的每个部分\n- 指出逻辑漏洞和方法问题\n- 检查写作质量\n- 给出具体修改建议\n- 输出结构化审稿意见"
  }
])
```

### 第 2 步：团队协作—并行搜索文献

```typescript
agent({
  team: [
    {
      agent: "lit-reviewer",
      task: "搜索关于'最低工资与就业'主题的文献，重点关注使用断点回归方法的论文。搜索过去10年的研究，包括中英文文献。将搜索结果写入共享目录。"
    },
    {
      agent: "method-expert",
      task: "搜索'断点回归设计在劳动经济学中的应用'的方法论文献。重点关注 RD 设计的有效性条件、带宽选择、多项式阶数等关键技术问题。将结果写入共享目录。"
    }
  ]
})
```

### 第 3 步：链式—分析数据 → 跑回归 → 写结果

```typescript
agent({
  chain: [
    {
      agent: "data-analyst",
      task: "读取数据集（假设有 minimum_wage_data.dta），执行：\n1. 描述性统计\n2. 断点回归（rdrobust）\n3. 输出回归表格"
    },
    {
      agent: "method-expert",
      task: "审查以下回归结果，评估识别策略的有效性，建议稳健性检验：\n{previous}"
    },
    {
      agent: "data-analyst",
      task: "根据方法专家的建议执行稳健性检验：\n1. 不同带宽\n2. 不同多项式阶数\n3. 安慰剂检验\n\n方法专家建议：\n{previous}"
    }
  ]
})
```

### 第 4 步：链式—撰写整篇论文

```typescript
agent({
  chain: [
    {
      agent: "paper-writer",
      task: "撰写论文引言部分。\n\n研究主题：最低工资对就业的影响：基于断点回归的新证据\n\n文献综述结果和回归结果在之前的对话中已讨论。\n\n引言需要包含：\n1. 研究背景与意义\n2. 现有文献的不足\n3. 本文的贡献\n4. 研究发现摘要\n5. 论文结构安排"
    },
    {
      agent: "paper-writer",
      task: "撰写文献综述部分。\n\n基于团队在共享目录中的搜索结果，组织文献综述。\n\n文献搜索结果在共享消息板中。\n\n{previous}"
    },
    {
      agent: "paper-writer",
      task: "撰写研究方法和数据部分。描述：\n1. 数据来源和样本\n2. 断点回归设计\n3. 识别策略\n4. 变量定义\n\n{previous}"
    },
    {
      agent: "paper-writer",
      task: "撰写实证结果部分。包括：\n1. 描述性统计\n2. 主回归结果\n3. 稳健性检验\n4. 异质性分析\n\n回归结果：\n{previous}"
    },
    {
      agent: "paper-writer",
      task: "撰写结论部分，然后合并所有部分为完整的 LaTeX 论文。\n\n{previous}"
    }
  ]
})
```

### 第 5 步：审稿 + 修改

```typescript
agent({
  chain: [
    {
      agent: "referee",
      task: "审阅整篇论文（假设已写入 paper.tex）。\n\n从以下角度评估：\n1. 研究问题的创新性\n2. 识别策略的严谨性\n3. 实证分析的完整性\n4. 写作质量与结构\n5. 与现有文献的对话\n\n输出结构化审稿意见。"
    },
    {
      agent: "paper-writer",
      task: "根据以下审稿意见修改论文：\n{previous}"
    }
  ]
})
```

### 第 6 步：清理

```typescript
cleanup_agents({ all: true })
```

---

## 最佳实践

### 智能体设计原则
- **单一职责**：每个 agent 只做一件事
- **最小权限**：只给必要的工具（如审稿人不需要 `bash`）
- **选对类型**：需要上下文用 `fork`，需要协作用 `team`，简单任务用 `standard`
- **多模型编排**：搜索用快模型（haiku），分析用强模型（sonnet）

### 执行模式选择
- **simple**：独立任务，无依赖
- **parallel**：任务之间无依赖，追求速度
- **chain**：任务之间有前后依赖，需要数据传递
- **team**：任务之间需要交流中间结果

### 嵌套调用
- 子 agent 的 `tools` 必须包含 `create_agents` 和 `agent` 才能继续嵌套
- 最多 3 层，防止失控

---

## 配置参考

### Agent 文件格式

文件位置：`.pi/agents/{name}.md`

```yaml
---
name: my-agent           # 必填，唯一标识符
description: 描述        # 必填
type: standard           # 可选：standard | fork | team（默认standard）
systemPrompt: 你的提示词  # 文件正文（frontmatter 之后）
tools: [read, write]     # 可选：允许的工具列表
model: provider/model    # 可选：指定模型
---
你的完整系统提示词写在这里……
```

### `create_agents` 参数

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `name` | string | ✅ | 2-50字符，小写字母数字连字符 |
| `description` | string | ✅ | 简短描述 |
| `systemPrompt` | string | ✅ | 完整系统提示词，至少10字符 |
| `type` | "standard"\|"fork"\|"team" | ❌ | 默认 "standard" |
| `tools` | string[] | ❌ | 如不指定则所有工具可用 |
| `model` | string | ❌ | 如不指定则使用主 agent 的模型 |

### `agent` 参数

| 模式 | 参数 | 说明 |
|------|------|------|
| **single** | `agent`, `task`, `timeout?`, `cwd?` | 单个 agent 执行 |
| **parallel** | `parallel: [{agent, task}]`, `timeout?` | 并行执行 |
| **chain** | `chain: [{agent, task}]` | 链式执行，`{previous}` 传结果 |
| **team** | `team: [{agent, task}]` | 团队协作，共享消息板 |

### `cleanup_agents` 参数

| 字段 | 类型 | 说明 |
|------|------|------|
| `agents` | string[] | 要删除的 agent 名称列表 |
| `all` | boolean | 设为 `true` 删除所有 project agents |

---

## 与 Claude Code 对比

| 能力 | Claude Code | 本扩展 |
|------|-------------|--------|
| Standard 模式 | ✅ | ✅ |
| Fork 模式（继承上下文） | ✅ 完整克隆 | ✅ 摘要注入 |
| Team 模式（通信） | ✅ 内置消息队列 | ✅ 文件系统消息板 |
| 嵌套调用 | ✅ | ✅ 最多3层 |
| 工具权限 | 读/写/网络粗粒度 | ⚡ **按工具名精确控制** |
| 多模型编排 | ❌ | ⚡ **每个 agent 可指定不同模型** |
| 智能体持久化 | ❌ 运行时态 | ⚡ **.md 文件跨 session 保留** |
| 进程隔离 | 同进程沙箱 | ⚡ **独立子进程** |
| 自动调度 | 有限 | ❌ |
| 错误跳过 | 可配置 | ❌ |
