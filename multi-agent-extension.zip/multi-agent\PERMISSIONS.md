# 智能体权限配置完整指南

有三种方式配置智能体的权限设置，效果完全一样，选最方便的用。

---

## 方式一：YAML 文件（手动编写）

在 `.pi/agents/` 目录下创建 `.md` 文件：

```yaml
---
name: data-analyst
description: 运行 Stata 回归并输出结果表格
type: fork                          # standard | fork | team
readonly: false                      # true = 只能读文件
tools: read, write, bash            # 白名单：只允许这些工具
disallowedTools: edit               # 黑名单：从可用工具中排除这些
model: opencode-go/mimo-v2.5        # 指定模型
maxTurns: 20                        # 最多执行20轮
---
你是一位计量经济学数据分析师……（system prompt 写在这里）
```

所有字段的完整说明：

| 字段 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `name` | ✅ | — | 唯一标识符，2-50字符，小写+连字符 |
| `description` | ✅ | — | 简短描述，显示在列表中 |
| （正文） | ✅ | — | 系统提示词，至少10字符 |
| `type` | ❌ | `standard` | `standard`=空白上下文, `fork`=继承会话历史, `team`=共享消息板 |
| `readonly` | ❌ | `false` | `true`=只读模式，等价于 `tools: read, ls, grep, find` |
| `tools` | ❌ | 全部可用 | 白名单：只允许列出的工具 |
| `disallowedTools` | ❌ | — | 黑名单：从可用工具中排除 |
| `model` | ❌ | 继承父级 | 指定模型，如 `claude-sonnet-4-5` |
| `maxTurns` | ❌ | 无限制 | 最大执行轮次，防止无限循环 |

### 常见配置模板

**只读审查员**（最安全）：
```yaml
---
name: code-reviewer
description: 审查代码，不修改任何文件
readonly: true
maxTurns: 15
---
你是一位代码审查专家……
```

**数据分析员**（能跑命令，不能改源码）：
```yaml
---
name: data-analyst
description: 运行 Stata 回归
tools: read, write, bash
disallowedTools: edit
maxTurns: 20
---
你是一位数据分析师，使用 Stata 执行回归分析……
```

**论文写手**（能读写编辑，但轮次受限）：
```yaml
---
name: paper-writer
description: 撰写经济学论文
type: fork
tools: read, write, edit, bash
maxTurns: 30
---
你是一位经济学论文撰写专家……
```

**安全研究员**（所有工具但排除危险操作）：
```yaml
---
name: researcher
description: 探索代码库并生成报告
disallowedTools: write, edit, bash
maxTurns: 10
---
你是一位代码研究专家……
```

---

## 方式二：`create_agents` 工具（LLM 调用）

直接告诉 AI 你想创建什么样的智能体，LLM 会调用 `create_agents` 工具：

```
帮我创建一个叫 data-reviewer 的智能体，类型是 fork，
只能读文件和跑 bash，不能写和编辑，最多跑 15 轮，
用 opencode-go/mimo-v2.5 模型。
```

AI 会生成：
```json
{
  "agents": [{
    "name": "data-reviewer",
    "description": "Review data analysis results",
    "systemPrompt": "You are a data reviewer...",
    "type": "fork",
    "readonly": false,
    "tools": ["read", "bash", "ls", "grep", "find"],
    "disallowedTools": ["write", "edit"],
    "maxTurns": 15,
    "model": "opencode-go/mimo-v2.5"
  }]
}
```

---

## 方式三：`/agent create` 交互式向导

在 pi 中输入 `/agent create`，逐步选择：

```
🧑‍💼 Agent name: data-reviewer
📝 Description: Reviews data analysis results

🎯 Type — how does it get context?
  ▸ standard    ← 空白上下文
    fork         ← 继承会话历史
    team         ← 共享消息板

🔒 Read-only? No               ← 选 Yes = 只能读文件

🛠️ Tool access?
  ▸ All tools     ← 无限制（默认）
    Allowlist      ← 白名单模式
    Denylist       ← 黑名单模式

（如果选 Allowlist:）
✅ Allowed tools: read, bash

（如果选 Denylist:）
❌ Denied tools: write, edit

🔄 Max turns (empty = unlimited): 15

🤖 Model (optional): opencode-go/mimo-v2.5

📋 System prompt: (编辑器打开……

Summary
  name:        data-reviewer
  desc:  Reviews data analysis results
  type:        fork
  full access
  deny:        write, edit
  maxTurns:    15
  model:       opencode-go/mimo-v2.5

Create this agent? Yes
```

---

## 权限优先级

```
readonly → 最高优先级
   ↓
tools（白名单）→ 如果设了 readonly，tools 被忽略
   ↓
disallowedTools（黑名单）→ 从白名单中移除指定工具
```

示例：

| readonly | tools | disallowedTools | 结果 |
|----------|-------|-----------------|------|
| `true` | — | — | 只有 read, ls, grep, find |
| `false` | — | — | 所有工具 |
| `false` | `read, bash` | — | 只有 read, bash |
| `false` | — | `write, edit` | 有 bug：当没有白名单时黑名单不生效¹ |
| `false` | `read, bash, write` | `write` | 只有 read, bash（write 被移除） |
| `true` | `read, bash` | — | 只有 read, ls, grep, find（readonly 覆盖 tools） |

> ¹ 当没有白名单时，pi 扩展无法枚举"所有可用工具"来排除，因为可用工具列表由 pi 核心决定。这种场景下的替代方案是：把白名单写全再排除，或用 `readonly: true`。

---

## 查看已有智能体的权限

```bash
/agent show data-reviewer
```

输出会包含 `tools` 和 `deny` 行：
```
name: data-reviewer
desc: Reviews data analysis results
type: fork
deny: write, edit
maxTurns: 15
model: opencode-go/mimo-v2.5
```

---

## 删除智能体

```bash
/agent delete data-reviewer
# 或删除全部项目智能体：
cleanup_agents({ all: true })
```