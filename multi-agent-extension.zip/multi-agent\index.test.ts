/**
 * Multi-Agent Extension — Unit Tests
 *
 * Tests core functionality:
 * - Input validation (createAgentFile)
 * - Agent YAML frontmatter round-trip (write → parse)
 * - Fork context collection
 * - Agent name resolution
 * - makeFailedResult helper
 * - Status tracking and session management
 * - Formatting utilities
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";

// ── Types ──

import type { AgentConfig, AgentCreateRequest, RunResult, UsageStats } from "./types.ts";
import {
  emptyUsage,
  totalUsage,
  makeFailedResult,
  getFinal,
  isFailed,
  getOutput,
  MAX_PARALLEL_TASKS,
  MAX_NESTED_DEPTH,
  CHAIN_PREVIOUS_MAX_CHARS,
} from "./types.ts";

// ── Agent Registry ──

import {
  validateAgentRequest,
  createAgentFile,
  formatAgentList,
  collectForkContext,
} from "./agent-registry.ts";

// ── Agent Executor ──

import { resolveAgentRef, checkAndConfirmAgent } from "./agent-executor.ts";

// ── Agent Status ──

import {
  agentStatusMap,
  agentSessions,
  addSession,
  updateSession,
  getOrCreateEntry,
  fmtDuration,
  fmtTokens,
  fmtUsage,
} from "./agent-status.ts";

// ════════════════════════════════════════
// Types & Utility Functions
// ════════════════════════════════════════

describe("emptyUsage", () => {
  it("should return zeroed usage stats", () => {
    const u = emptyUsage();
    expect(u.input).toBe(0);
    expect(u.output).toBe(0);
    expect(u.cacheRead).toBe(0);
    expect(u.cacheWrite).toBe(0);
    expect(u.cost).toBe(0);
    expect(u.contextTokens).toBe(0);
    expect(u.turns).toBe(0);
  });
});

describe("totalUsage", () => {
  it("should sum up usage across multiple results", () => {
    const results: RunResult[] = [
      makeFailedResult("a", "task", "err", { usage: { input: 100, output: 50, cacheRead: 10, cacheWrite: 5, cost: 1, contextTokens: 200, turns: 1 } }),
      makeFailedResult("b", "task", "err", { usage: { input: 200, output: 100, cacheRead: 20, cacheWrite: 10, cost: 2, contextTokens: 400, turns: 2 } }),
    ];
    const total = totalUsage(results);
    expect(total.input).toBe(300);
    expect(total.output).toBe(150);
    expect(total.cacheRead).toBe(30);
    expect(total.cacheWrite).toBe(15);
    expect(total.cost).toBe(3);
    expect(total.turns).toBe(3);
  });
});

describe("makeFailedResult", () => {
  it("should create a properly structured failed result", () => {
    const result = makeFailedResult("test-agent", "do something", "Something went wrong");
    expect(result.agent).toBe("test-agent");
    expect(result.task).toBe("do something");
    expect(result.errorMessage).toBe("Something went wrong");
    expect(result.exitCode).toBe(1);
    expect(result.mode).toBe("spawn");
    expect(result.origin).toBe("inline");
    expect(result.timedOut).toBe(false);
    expect(result.filesProduced).toEqual([]);
    expect(result.output).toBe("");
  });

  it("should allow overriding fields", () => {
    const result = makeFailedResult("a", "t", "err", { exitCode: 42, timedOut: true });
    expect(result.exitCode).toBe(42);
    expect(result.timedOut).toBe(true);
    expect(result.errorMessage).toBe("err");
  });
});

describe("isFailed", () => {
  it("should detect failed results by exitCode", () => {
    expect(isFailed(makeFailedResult("a", "t", "err"))).toBe(true);
    expect(isFailed({ ...makeFailedResult("a", "t", "err"), exitCode: 0 })).toBe(false);
  });

  it("should detect failed results by stopReason", () => {
    const r = makeFailedResult("a", "t", "err", { exitCode: 0, stopReason: "error" });
    expect(isFailed(r)).toBe(true);
  });

  it("should detect timeout", () => {
    const r = makeFailedResult("a", "t", "err", { exitCode: 0, stopReason: "timeout" });
    expect(isFailed(r)).toBe(true);
  });

  it("should not mark successful results as failed", () => {
    const r: RunResult = {
      agent: "a", origin: "project", task: "t", mode: "spawn", exitCode: 0,
      output: "ok", messages: [], stderr: "", usage: emptyUsage(), filesProduced: [], timedOut: false,
    };
    expect(isFailed(r)).toBe(false);
  });
});

describe("getOutput", () => {
  it("should return output for successful results", () => {
    const r: RunResult = {
      agent: "a", origin: "project", task: "t", mode: "spawn", exitCode: 0,
      output: "hello", messages: [], stderr: "", usage: emptyUsage(), filesProduced: [], timedOut: false,
    };
    expect(getOutput(r)).toBe("hello");
  });

  it("should prefer errorMessage for failed results", () => {
    const r = makeFailedResult("a", "t", "Error msg");
    expect(getOutput(r)).toBe("Error msg");
  });
});

// ════════════════════════════════════════
// Agent Registry — Validation
// ════════════════════════════════════════

describe("validateAgentRequest", () => {
  const validRequest: AgentCreateRequest = {
    name: "test-agent",
    description: "A test agent",
    systemPrompt: "You are a helpful test agent that does things.",
  };

  it("should accept valid requests", () => {
    expect(validateAgentRequest(validRequest)).toBeNull();
  });

  it("should reject missing name", () => {
    expect(validateAgentRequest({ ...validRequest, name: "" })).not.toBeNull();
  });

  it("should reject names that are too short", () => {
    expect(validateAgentRequest({ ...validRequest, name: "a" })).not.toBeNull();
  });

  it("should reject names that are too long", () => {
    expect(validateAgentRequest({ ...validRequest, name: "a".repeat(51) })).not.toBeNull();
  });

  it("should reject invalid name characters", () => {
    expect(validateAgentRequest({ ...validRequest, name: "Test_Agent" })).not.toBeNull();
    expect(validateAgentRequest({ ...validRequest, name: "test agent" })).not.toBeNull();
  });

  it("should accept valid hyphenated names", () => {
    expect(validateAgentRequest({ ...validRequest, name: "data-analyzer" })).toBeNull();
  });

  it("should reject names starting with hyphens", () => {
    expect(validateAgentRequest({ ...validRequest, name: "-agent" })).not.toBeNull();
  });

  it("should reject missing description", () => {
    expect(validateAgentRequest({ ...validRequest, description: "" })).not.toBeNull();
  });

  it("should reject short system prompts", () => {
    expect(validateAgentRequest({ ...validRequest, systemPrompt: "Hi" })).not.toBeNull();
  });

  it("should reject invalid types", () => {
    expect(validateAgentRequest({ ...validRequest, type: "invalid" as any })).not.toBeNull();
  });

  it("should accept fork and team types", () => {
    expect(validateAgentRequest({ ...validRequest, type: "fork" })).toBeNull();
    expect(validateAgentRequest({ ...validRequest, type: "team" })).toBeNull();
  });

  it("should accept tools array", () => {
    expect(validateAgentRequest({ ...validRequest, tools: ["read", "write"] })).toBeNull();
  });

  it("should reject non-array tools", () => {
    expect(validateAgentRequest({ ...validRequest, tools: "read" as any })).not.toBeNull();
  });

  it("should accept disallowedTools array", () => {
    expect(validateAgentRequest({ ...validRequest, disallowedTools: ["write", "edit"] })).toBeNull();
  });

  it("should reject non-array disallowedTools", () => {
    expect(validateAgentRequest({ ...validRequest, disallowedTools: "write" as any })).not.toBeNull();
  });

  it("should accept valid maxTurns", () => {
    expect(validateAgentRequest({ ...validRequest, maxTurns: 15 })).toBeNull();
  });

  it("should reject invalid maxTurns", () => {
    expect(validateAgentRequest({ ...validRequest, maxTurns: 0 })).not.toBeNull();
    expect(validateAgentRequest({ ...validRequest, maxTurns: -5 })).not.toBeNull();
  });
});

describe("createAgentFile", () => {
  let tmpDir: string;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "pi-ma-test-"));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // Helper to create .pi/agents directory
  function setupAgentsDir(cwd: string): string {
    const dir = path.join(cwd, ".pi", "agents");
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  it("should create a valid agent file", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "my-agent",
      description: "A helpful agent",
      systemPrompt: "You are a helpful assistant that does things.",
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(fs.existsSync(result.path)).toBe(true);
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).toContain("name: my-agent");
      expect(content).toContain("description: A helpful agent");
      expect(content).toContain("You are a helpful assistant that does things.");
    }
  });

  it("should include tools in frontmatter", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "tools-agent",
      description: "An agent with tools",
      systemPrompt: "You use specific tools.",
      tools: ["read", "write", "bash"],
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).toContain("tools: read, write, bash");
    }
  });

  it("should include disallowedTools in frontmatter", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "deny-agent",
      description: "An agent with denied tools",
      systemPrompt: "You cannot write.",
      disallowedTools: ["write", "edit"],
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).toContain("disallowedTools: write, edit");
    }
  });

  it("should include maxTurns in frontmatter", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "limited-agent",
      description: "An agent with turn limit",
      systemPrompt: "You have limited turns.",
      maxTurns: 15,
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).toContain("maxTurns: 15");
    }
  });

  it("should include type and model in frontmatter", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "typed-agent",
      description: "A typed agent",
      systemPrompt: "You are a specialized agent.",
      type: "fork",
      model: "opencode-go/mimo-v2.5",
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).toContain("type: fork");
      expect(content).toContain("model: opencode-go/mimo-v2.5");
    }
  });

  it("should not include standard type or empty fields", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "simple-agent",
      description: "Simple",
      systemPrompt: "You are simple.",
      type: "standard",
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      const content = fs.readFileSync(result.path, "utf-8");
      expect(content).not.toContain("type:");
      expect(content).not.toContain("tools:");
      expect(content).not.toContain("model:");
    }
  });

  it("should reject invalid names", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "INVALID",
      description: "Test",
      systemPrompt: "You are a test.",
    });
    expect(result.ok).toBe(false);
  });

  it("should reject short system prompts", () => {
    setupAgentsDir(tmpDir);
    const result = createAgentFile(tmpDir, {
      name: "short-prompt",
      description: "Test",
      systemPrompt: "Hi",
    });
    expect(result.ok).toBe(false);
  });
});

describe("formatAgentList", () => {
  it("should format empty list", () => {
    expect(formatAgentList([])).toBe("No agents found.");
  });

  it("should format project agents", () => {
    const agents: AgentConfig[] = [
      { name: "reviewer", description: "Reviews code", systemPrompt: "", origin: "project" },
    ];
    const result = formatAgentList(agents);
    expect(result).toContain("Project agents");
    expect(result).toContain("reviewer");
    expect(result).toContain("Reviews code");
  });

  it("should format global agents", () => {
    const agents: AgentConfig[] = [
      { name: "global-helper", description: "Helps globally", systemPrompt: "", origin: "global" },
    ];
    const result = formatAgentList(agents);
    expect(result).toContain("Global agents");
    expect(result).toContain("global-helper");
  });

  it("should show type, readonly, and model tags", () => {
    const agents: AgentConfig[] = [
      { name: "special", description: "Special agent", systemPrompt: "", origin: "project", type: "fork", readonly: true, model: "gpt-4" },
    ];
    const result = formatAgentList(agents);
    expect(result).toContain("type: fork");
    expect(result).toContain("readonly");
    expect(result).toContain("model: gpt-4");
  });
});

// ════════════════════════════════════════
// Fork Context
// ════════════════════════════════════════

describe("collectForkContext", () => {
  it("should extract file references with various extensions", () => {
    const entries = [
      {
        type: "message",
        message: {
          role: "user" as const,
          content: "Please analyze the data in /path/to/data.dta and /path/to/config.yaml",
        },
      },
      {
        type: "message",
        message: {
          role: "assistant" as const,
          content: "I'll check analysis.py and results.csv for you.",
        },
      },
    ];

    const ctx = collectForkContext(entries as any);
    expect(ctx.referencedFiles).toContain("/path/to/data.dta");
    expect(ctx.referencedFiles).toContain("/path/to/config.yaml");
    expect(ctx.referencedFiles).toContain("analysis.py");
    expect(ctx.referencedFiles).toContain("results.csv");
    expect(ctx.totalTurns).toBe(2);
  });

  it("should handle empty entries", () => {
    const ctx = collectForkContext([]);
    expect(ctx.recentMessages).toBe("");
    expect(ctx.referencedFiles).toEqual([]);
    expect(ctx.totalTurns).toBe(0);
  });

  it("should truncate long messages", () => {
    const entries = [
      {
        type: "message",
        message: {
          role: "user" as const,
          content: "x".repeat(5000),
        },
      },
    ];

    const ctx = collectForkContext(entries as any);
    // The message should be truncated in the recentMessages output
    expect(ctx.totalTurns).toBe(1);
  });
});

// ════════════════════════════════════════
// Agent Resolution
// ════════════════════════════════════════

describe("resolveAgentRef", () => {
  const agents: AgentConfig[] = [
    { name: "reviewer", description: "Reviews code", systemPrompt: "You review code.", origin: "project", type: "fork" },
    { name: "writer", description: "Writes text", systemPrompt: "You write text.", origin: "global" },
  ];

  it("should resolve a known agent by name", () => {
    const { config, name, known } = resolveAgentRef("reviewer", agents);
    expect(name).toBe("reviewer");
    expect(known).toBe(true);
    expect(config.name).toBe("reviewer");
  });

  it("should create an inline agent for unknown names", () => {
    const { config, name, known } = resolveAgentRef("unknown-agent", agents);
    expect(name).toBe("unknown-agent");
    expect(known).toBe(false);
  });

  it("should resolve inline agent specs", () => {
    const spec = { systemPrompt: "You are inline.", name: "inline-test" };
    const { config, name, known } = resolveAgentRef(spec, agents);
    expect(name).toBe("inline-test");
    expect(known).toBe(true);
    expect(config.systemPrompt).toBe("You are inline.");
  });
});

describe("checkAndConfirmAgent", () => {
  const agents: AgentConfig[] = [
    { name: "reviewer", description: "Reviews code", systemPrompt: "You review code.", origin: "project" },
  ];

  it("should confirm known agents", () => {
    const result = checkAndConfirmAgent("reviewer", agents);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.name).toBe("reviewer");
    }
  });

  it("should reject unknown agents with available list", () => {
    const result = checkAndConfirmAgent("nonexistent", agents);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error).toContain("Unknown agent");
      expect(result.error).toContain("reviewer");
    }
  });

  it("should accept inline agent specs", () => {
    const result = checkAndConfirmAgent({ systemPrompt: "You are inline." }, agents);
    expect(result.ok).toBe(true);
  });
});

// ════════════════════════════════════════
// Status Tracking
// ════════════════════════════════════════

describe("Agent Status Tracking", () => {
  beforeEach(() => {
    agentStatusMap.clear();
    agentSessions.length = 0;
  });

  it("should create new status entries", () => {
    const entry = getOrCreateEntry("test-agent");
    expect(entry.name).toBe("test-agent");
    expect(entry.status).toBe("pending");
    expect(agentStatusMap.size).toBe(1);
  });

  it("should return existing entries for same name", () => {
    const entry1 = getOrCreateEntry("test-agent");
    entry1.status = "running";
    const entry2 = getOrCreateEntry("test-agent");
    expect(entry2.status).toBe("running");
    expect(agentStatusMap.size).toBe(1);
  });

  it("should evict oldest entries when map exceeds limit", () => {
    for (let i = 0; i < 102; i++) {
      getOrCreateEntry(`agent-${i}`);
    }
    // Map should not grow beyond ~101 (MAX_STATUS_ENTRIES + 1 from the eviction check)
    expect(agentStatusMap.size).toBeLessThanOrEqual(102);
  });
});

describe("Agent Session Tracking", () => {
  beforeEach(() => {
    agentSessions.length = 0;
  });

  it("should add sessions with IDs", () => {
    const session = addSession({
      agentName: "test",
      task: "do something",
      mode: "single",
      status: "running",
      background: false,
    });

    expect(session.id).toBeTruthy();
    expect(session.agentName).toBe("test");
    expect(session.startTime).toBeGreaterThan(0);
    expect(agentSessions.length).toBe(1);
  });

  it("should update sessions by ID", () => {
    const session = addSession({
      agentName: "test",
      task: "do something",
      mode: "single",
      status: "running",
      background: false,
    });

    updateSession(session.id, { status: "done", endTime: Date.now() });
    expect(agentSessions[0].status).toBe("done");
    expect(agentSessions[0].endTime).toBeGreaterThan(0);
  });

  it("should evict old sessions when limit exceeded", () => {
    for (let i = 0; i < 205; i++) {
      addSession({
        agentName: `agent-${i}`,
        task: `task ${i}`,
        mode: "single",
        status: "running",
        background: false,
      });
    }
    // Should be capped at MAX_SESSION_ENTRIES (200)
    expect(agentSessions.length).toBeLessThanOrEqual(200);
  });
});

// ════════════════════════════════════════
// Formatting Utilities
// ════════════════════════════════════════

describe("fmtDuration", () => {
  it("should format milliseconds", () => {
    expect(fmtDuration(500)).toBe("500ms");
  });

  it("should format seconds", () => {
    expect(fmtDuration(5000)).toBe("5s");
    expect(fmtDuration(59000)).toBe("59s");
  });

  it("should format minutes and seconds", () => {
    expect(fmtDuration(65000)).toBe("1m5s");
    expect(fmtDuration(125000)).toBe("2m5s");
  });
});

describe("fmtTokens", () => {
  it("should format small numbers directly", () => {
    expect(fmtTokens(999)).toBe("999");
  });

  it("should format thousands with one decimal", () => {
    expect(fmtTokens(1500)).toBe("1.5k");
  });

  it("should format large thousands", () => {
    expect(fmtTokens(15000)).toBe("15k");
  });

  it("should format millions", () => {
    expect(fmtTokens(1500000)).toBe("1.5M");
  });
});

describe("fmtUsage", () => {
  it("should format turns", () => {
    expect(fmtUsage({ ...emptyUsage(), turns: 3 })).toContain("3t");
  });

  it("should format tokens", () => {
    const u = { ...emptyUsage(), input: 1000, output: 500 };
    expect(fmtUsage(u)).toContain("↑1k");
    expect(fmtUsage(u)).toContain("↓500");
  });

  it("should include model name", () => {
    expect(fmtUsage(emptyUsage(), "gpt-4")).toContain("gpt-4");
  });

  it("should format cost", () => {
    expect(fmtUsage({ ...emptyUsage(), cost: 0.0015 })).toContain("$0.0015");
  });
});

// ════════════════════════════════════════
// Constants
// ════════════════════════════════════════

describe("Constants", () => {
  it("should have reasonable limits", () => {
    expect(MAX_PARALLEL_TASKS).toBe(8);
    expect(MAX_NESTED_DEPTH).toBe(3);
    expect(CHAIN_PREVIOUS_MAX_CHARS).toBe(100_000);
  });
});

// ════════════════════════════════════════
// resolveSpec — disallowedTools
// ════════════════════════════════════════

import { resolveSpec } from "./agent-runner.ts";

describe("resolveSpec", () => {
  it("should filter disallowedTools from allowlist", () => {
    const spec = resolveSpec({
      name: "test",
      description: "test",
      systemPrompt: "test",
      tools: ["read", "write", "edit", "bash"],
      disallowedTools: ["write", "edit"],
    });
    expect(spec.tools).toBeDefined();
    expect(spec.tools).toContain("read");
    expect(spec.tools).toContain("bash");
    expect(spec.tools).not.toContain("write");
    expect(spec.tools).not.toContain("edit");
  });

  it("should respect readonly over tools", () => {
    const spec = resolveSpec({
      name: "test",
      description: "test",
      systemPrompt: "test",
      readonly: true,
      tools: ["read", "write"],
    });
    expect(spec.tools).toEqual(["read", "ls", "grep", "find"]);
  });

  it("should pass through maxTurns", () => {
    const spec = resolveSpec({
      name: "test",
      description: "test",
      systemPrompt: "test",
      maxTurns: 15,
    });
    expect(spec.maxTurns).toBe(15);
  });

  it("should default maxTurns to undefined", () => {
    const spec = resolveSpec({
      name: "test",
      description: "test",
      systemPrompt: "test",
    });
    expect(spec.maxTurns).toBeUndefined();
  });
});