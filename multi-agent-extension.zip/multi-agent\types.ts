/**
 * Multi-Agent Extension — Type Definitions and Constants
 *
 * All shared types, interfaces, constants, and pure utility functions
 * live here so every other module can import from a single source of truth.
 */

import type { Message } from "@earendil-works/pi-ai";

// ── Agent Type ──

export type AgentType = "standard" | "fork" | "team";

// ── Agent Definition ──

export interface AgentSpec {
  name: string;
  description: string;
  systemPrompt: string;
  type?: AgentType;
  readonly?: boolean;
  tools?: string[];            // per-agent tool allowlist; undefined = all tools
  disallowedTools?: string[];  // per-agent tool denylist; removed from available tools
  model?: string;
  maxTurns?: number;           // max agentic turns before stopping (default: unlimited)
}

export type AgentOrigin = "global" | "project" | "inline";

export interface AgentConfig extends AgentSpec {
  origin: AgentOrigin;
  filePath?: string;
}

// ── Creation Request ──

export interface AgentCreateRequest {
  name: string;
  description: string;
  systemPrompt: string;
  type?: AgentType;
  readonly?: boolean;
  tools?: string[];
  disallowedTools?: string[];
  model?: string;
  maxTurns?: number;
  scope?: "project" | "global";  // default: project
}

// ── Execution ──

export type RunMode = "spawn";

export interface RunResult {
  agent: string;
  origin: AgentOrigin;
  task: string;
  mode: RunMode;
  exitCode: number;
  output: string;
  messages: Message[];
  stderr: string;
  usage: UsageStats;
  model?: string;
  stopReason?: string;
  errorMessage?: string;
  filesProduced: string[];
  step?: number;
  timedOut?: boolean;
}

// ── Usage ──

export interface UsageStats {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  cost: number;
  contextTokens: number;
  turns: number;
}

export function emptyUsage(): UsageStats {
  return { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, cost: 0, contextTokens: 0, turns: 0 };
}

export function totalUsage(results: RunResult[]): UsageStats {
  const t = emptyUsage();
  for (const r of results) {
    t.input += r.usage.input;
    t.output += r.usage.output;
    t.cacheRead += r.usage.cacheRead;
    t.cacheWrite += r.usage.cacheWrite;
    t.cost += r.usage.cost;
    t.turns += r.usage.turns;
  }
  return t;
}

/** Convenience factory for a failed RunResult with sensible defaults. */
export function makeFailedResult(
  agent: string,
  task: string,
  errorMessage: string,
  overrides?: Partial<RunResult>,
): RunResult {
  return {
    agent,
    origin: "inline",
    task,
    mode: "spawn",
    exitCode: 1,
    output: "",
    messages: [],
    stderr: "",
    usage: emptyUsage(),
    errorMessage,
    filesProduced: [],
    timedOut: false,
    ...overrides,
  };
}

// ── RunResult helpers ──

/** Extract the last assistant text from a message list. */
export function getFinal(messages: Message[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role === "assistant") {
      for (const p of m.content) {
        if (p.type === "text") return p.text;
      }
    }
  }
  return "";
}

export function isFailed(r: RunResult): boolean {
  return r.exitCode !== 0 || r.stopReason === "error" || r.stopReason === "aborted" || r.stopReason === "timeout";
}

export function getOutput(r: RunResult): string {
  if (isFailed(r)) return r.errorMessage || r.stderr || r.output || "(no output)";
  return r.output || "(no output)";
}

// ── Tool Detail (returned to LLM) ──

export interface AgentToolDetail {
  mode: "single" | "parallel" | "chain" | "team";
  results: RunResult[];
  totalUsage: UsageStats;
}

// ── Team Config ──

export interface TeamConfig {
  teamId: string;
  teamDir: string;
  members: TeamMember[];
}

export interface TeamMember {
  name: string;
  task: string;
  model?: string;
}

// ── Shared Contexts ──

export interface ForkContext {
  recentMessages: string;
  referencedFiles: string[];
  totalTurns: number;
}

export interface TeamContext {
  teamId: string;
  teamDir: string;
  memberNames: string[];
  memberTasks: string[];
}

// ── Agent Status & Sessions ──

export interface AgentStatus {
  name: string;
  status: "pending" | "running" | "done" | "failed";
  startTime?: number;
  endTime?: number;
  usage: UsageStats;
  error?: string;
  step?: number;
}

export interface AgentSession {
  id: string;
  agentName: string;
  task: string;
  mode: "single" | "parallel" | "chain" | "team";
  status: "pending" | "running" | "done" | "failed";
  startTime: number;
  endTime?: number;
  duration?: number;
  model?: string;
  error?: string;
  output?: string;
  background: boolean;
}

// ── Display Types ──

export type DisplayItem =
  | { type: "text"; text: string }
  | { type: "toolCall"; name: string; args: Record<string, any> };

// ── Constants ──

export const MAX_PARALLEL_TASKS = 8;
export const MAX_CONCURRENCY = 4;
export const MAX_NESTED_DEPTH = 3;
export const DEFAULT_TIMEOUT_MS = 300_000;   // 5 minutes
export const DEFAULT_MAX_TURNS = 30;             // max agentic turns per agent spawn
export const MAX_STATUS_ENTRIES = 100;
export const MAX_SESSION_ENTRIES = 200;
export const FORK_MAX_TURNS = 20;
export const FORK_MAX_FILES = 30;
export const FORK_MSG_CHAR_LIMIT = 2000;       // increased from 1000 for better fidelity
export const FORK_TOOL_RESULT_LIMIT = 800;       // max chars per tool result in fork context
export const FORK_MAX_RECENT_FILES = 5;          // full content of most recently referenced files
export const CHAIN_PREVIOUS_MAX_CHARS = 100_000;
export const OUTPUT_CAP_BYTES = 50 * 1024;
export const COLLAPSED_ITEMS = 10;
export const SESSION_TEXT_CAP = 3000;

export const READONLY_TOOLS = ["read", "ls", "grep", "find"];

// All known pi tools (used when no allowlist is specified)
export const ALL_KNOWN_TOOLS = [
  "read", "write", "edit", "bash", "ls", "grep", "find",
  "create_agents", "agent", "cleanup_agents",
];

// File extensions recognized in fork context (broad coverage for academia & dev)
export const FILE_EXT_PATTERN = /[\w\-./\\]+\.(ts|js|tsx|jsx|py|rs|go|md|json|css|html|svelte|vue|sql|txt|csv|yaml|yml|toml|cfg|ini|log|dta|R|r|do|tex|bib|sty|cls|scss|less|sh|bash|zsh|fish|ps1|bat|dockerfile|makefile|cmake|gradle|xml|svg|proto|graphql|gql|tf|hcl|lock|env|gitignore|editorconfig|prettierrc|eslintrc)[\w\-./\\]*/gi;