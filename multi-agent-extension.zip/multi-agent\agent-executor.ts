/**
 * Agent Executor — Resolve, validate, and execute agents
 *
 * Provides four execution modes (single, parallel, chain, team)
 * and shared agent resolution/validation logic.
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { ExtensionContext } from "@earendil-works/pi-coding-agent";
import type {
  AgentConfig,
  AgentSpec,
  AgentToolDetail,
  ForkContext,
  RunResult,
  TeamContext,
} from "./types.ts";
import {
  CHAIN_PREVIOUS_MAX_CHARS,
  MAX_CONCURRENCY,
  MAX_PARALLEL_TASKS,
  emptyUsage,
  isFailed,
  makeFailedResult,
  totalUsage,
} from "./types.ts";
import { collectForkContext, discoverAgents } from "./agent-registry.ts";
import { mapWithLimit, runAgent } from "./agent-runner.ts";
import { addSession, getOrCreateEntry, updateSession } from "./agent-status.ts";

// ── Agent Resolution ──

/**
 * Resolve an agent reference (name string or inline spec) to an AgentConfig.
 * Returns { config, name, known } where `known` indicates the agent was found in the registry.
 */
export function resolveAgentRef(
  agentRef: string | Record<string, any>,
  agents: AgentConfig[],
): { config: AgentConfig | AgentSpec; name: string; known: boolean } {
  if (typeof agentRef === "string") {
    const found = agents.find((a) => a.name === agentRef);
    if (found) return { config: found, name: found.name, known: true };
    return {
      config: {
        name: agentRef,
        description: `Agent '${agentRef}'`,
        systemPrompt: `You are agent '${agentRef}'. Complete the task.`,
        origin: "inline",
      },
      name: agentRef,
      known: false,
    };
  }
  const spec = agentRef as AgentSpec;
  return {
    config: {
      name: spec.name || "inline",
      description: spec.description || "Inline agent",
      systemPrompt: spec.systemPrompt,
      tools: spec.tools,
      model: spec.model,
      origin: "inline",
    },
    name: spec.name || "inline",
    known: true,
  };
}

/**
 * Resolve and validate an agent reference.
 * For string references, ensures the agent exists in the registry.
 * Returns error with available agents if not found.
 */
export function checkAndConfirmAgent(
  agentRef: string | Record<string, any>,
  agents: AgentConfig[],
): { ok: true; config: AgentConfig | AgentSpec; name: string } | { ok: false; error: string } {
  const { config, name, known } = resolveAgentRef(agentRef, agents);
  if (!known) {
    const available = agents.map((a) => a.name).join(", ") || "(none)";
    return { ok: false, error: `Unknown agent: "${name}". Available: ${available}` };
  }
  return { ok: true, config, name };
}

// ── Helpers ──

function isForkType(config: AgentConfig | AgentSpec): boolean {
  return "type" in config && (config as any).type === "fork";
}

// ── Single Mode ──

export async function executeSingleMode(
  agentRef: string | Record<string, any>,
  task: string,
  ctx: ExtensionContext,
  signal: AbortSignal | undefined,
  produces?: string[],
  cwd?: string,
  forkCtx?: ForkContext,
): Promise<{ content: Array<{ type: "text"; text: string }>; details: AgentToolDetail; isError?: boolean }> {
  const agents = discoverAgents(ctx.cwd);
  const check = checkAndConfirmAgent(agentRef, agents);

  if (!check.ok) {
    return {
      content: [{ type: "text" as const, text: check.error }],
      details: { mode: "single" as const, results: [], totalUsage: emptyUsage() },
      isError: true,
    };
  }

  ctx.ui?.setStatus("agent-single", `Running ${check.name}...`);

  const entry = getOrCreateEntry(check.name);
  entry.status = "running";
  entry.startTime = Date.now();

  const ses = addSession({ agentName: check.name, task, mode: "single" as const, status: "running", background: false });

  try {
    const result = await runAgent(check.config, task, {
      cwd: cwd || ctx.cwd,
      signal,
      produces,
      forkContext: isForkType(check.config) && forkCtx ? forkCtx : undefined,
    });

    entry.status = isFailed(result) ? "failed" : "done";
    entry.endTime = Date.now();
    entry.usage = result.usage;
    ctx.ui?.setStatus("agent-single", undefined);

    if (isFailed(result)) {
      const output = result.output || result.errorMessage || "Unknown error";
      updateSession(ses.id, { status: "failed", endTime: Date.now(), output, error: result.errorMessage });
      return {
        content: [{ type: "text" as const, text: `Agent ${check.name} failed: ${output}` }],
        details: { mode: "single" as const, results: [result], totalUsage: totalUsage([result]) },
        isError: true,
      };
    }

    updateSession(ses.id, { status: "done", endTime: Date.now(), output: result.output });
    return {
      content: [{ type: "text" as const, text: result.output || "(no output)" }],
      details: { mode: "single" as const, results: [result], totalUsage: totalUsage([result]) },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    entry.status = "failed";
    entry.endTime = Date.now();
    entry.error = errorMessage;
    ctx.ui?.setStatus("agent-single", undefined);

    const failedResult = makeFailedResult(check.name, task, errorMessage);

    updateSession(ses.id, { status: "failed", endTime: Date.now(), error: errorMessage });

    return {
      content: [{ type: "text" as const, text: `Agent ${check.name} failed: ${errorMessage}` }],
      details: { mode: "single" as const, results: [failedResult], totalUsage: emptyUsage() },
      isError: true,
    };
  }
}

// ── Parallel Mode ──

export async function executeParallelMode(
  parallelTasks: Array<{ agent: string | Record<string, any>; task: string; produces?: string[]; cwd?: string }>,
  ctx: ExtensionContext,
  signal: AbortSignal | undefined,
  forkCtx: ForkContext,
  agents?: AgentConfig[],
): Promise<{ content: Array<{ type: "text"; text: string }>; details: AgentToolDetail; isError?: boolean }> {
  const allAgents = agents ?? discoverAgents(ctx.cwd);

  if (parallelTasks.length > MAX_PARALLEL_TASKS) {
    return {
      content: [{ type: "text" as const, text: `Too many parallel tasks (${parallelTasks.length}). Maximum is ${MAX_PARALLEL_TASKS}.` }],
      details: { mode: "parallel" as const, results: [], totalUsage: emptyUsage() },
      isError: true,
    };
  }

  const results: RunResult[] = new Array(parallelTasks.length).fill(null);

  ctx.ui?.setStatus("agent-parallel", `Running ${parallelTasks.length} agents in parallel...`);

  await mapWithLimit(parallelTasks, MAX_CONCURRENCY, async (task, i) => {
    const { config, name } = resolveAgentRef(task.agent, allAgents);

    const entry = getOrCreateEntry(name);
    entry.status = "running";
    entry.startTime = Date.now();

    const ses = addSession({ agentName: name, task: task.task, mode: "parallel" as const, status: "running", background: false });

    try {
      const result = await runAgent(config, task.task, {
        cwd: task.cwd || ctx.cwd,
        signal,
        produces: task.produces,
        forkContext: isForkType(config) ? forkCtx : undefined,
      });

      results[i] = result;
      entry.status = isFailed(result) ? "failed" : "done";
      entry.endTime = Date.now();
      entry.usage = result.usage;
      updateSession(ses.id, {
        status: isFailed(result) ? "failed" : "done",
        endTime: Date.now(),
        output: result.output,
        error: result.errorMessage,
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      results[i] = makeFailedResult(name, task.task, errorMessage);
      entry.status = "failed";
      entry.endTime = Date.now();
      entry.error = errorMessage;
      updateSession(ses.id, { status: "failed", endTime: Date.now(), error: errorMessage });
    }
  });

  ctx.ui?.setStatus("agent-parallel", undefined);

  const successCount = results.filter((r) => !isFailed(r)).length;
  const output = results.map((r, i) => {
    const status = isFailed(r) ? "❌ Failed" : "✅ Success";
    return `**Task ${i + 1}** (${r.agent}): ${status}\n\n${r.output || r.errorMessage || "(no output)"}`;
  }).join("\n\n---\n\n");

  return {
    content: [{ type: "text" as const, text: `Parallel execution completed: ${successCount}/${parallelTasks.length} succeeded.\n\n${output}` }],
    details: { mode: "parallel" as const, results, totalUsage: totalUsage(results) },
  };
}

// ── Chain Mode ──

export async function executeChainMode(
  chainSteps: Array<{ agent: string | Record<string, any>; task: string; produces?: string[]; cwd?: string }>,
  ctx: ExtensionContext,
  signal: AbortSignal | undefined,
  forkCtx: ForkContext,
  agents?: AgentConfig[],
): Promise<{ content: Array<{ type: "text"; text: string }>; details: AgentToolDetail; isError?: boolean }> {
  const allAgents = agents ?? discoverAgents(ctx.cwd);
  const results: RunResult[] = [];
  let previousOutput = "";

  for (let i = 0; i < chainSteps.length; i++) {
    const step = chainSteps[i];

    // Truncate {previous} substitution to prevent context overflow
    let task = step.task;
    if (previousOutput.length > CHAIN_PREVIOUS_MAX_CHARS) {
      previousOutput = previousOutput.slice(0, CHAIN_PREVIOUS_MAX_CHARS) + "\n\n[... output truncated ...]";
    }
    task = task.replace(/\{previous\}/g, previousOutput);

    const check = checkAndConfirmAgent(step.agent, allAgents);
    if (!check.ok) {
      return {
        content: [{ type: "text" as const, text: check.error }],
        details: { mode: "chain" as const, results, totalUsage: totalUsage(results) },
        isError: true,
      };
    }

    ctx.ui?.setStatus("agent-chain", `Step ${i + 1}/${chainSteps.length}: ${check.name}`);

    const entry = getOrCreateEntry(check.name);
    entry.status = "running";
    entry.startTime = Date.now();
    entry.step = i + 1;

    const ses = addSession({ agentName: check.name, task, mode: "chain" as const, status: "running", background: false });

    try {
      const result = await runAgent(check.config, task, {
        cwd: step.cwd || ctx.cwd,
        signal,
        produces: step.produces,
        forkContext: isForkType(check.config) ? forkCtx : undefined,
      });

      results.push(result);
      updateSession(ses.id, {
        status: isFailed(result) ? "failed" : "done",
        endTime: Date.now(),
        output: result.output,
        error: result.errorMessage,
      });
      entry.status = isFailed(result) ? "failed" : "done";
      entry.endTime = Date.now();
      entry.usage = result.usage;

      if (isFailed(result)) {
        ctx.ui?.setStatus("agent-chain", undefined);
        return {
          content: [{ type: "text" as const, text: `Chain failed at step ${i + 1} (${check.name}): ${result.output || result.errorMessage || "Unknown error"}` }],
          details: { mode: "chain" as const, results, totalUsage: totalUsage(results) },
          isError: true,
        };
      }

      previousOutput = result.output || "";
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      updateSession(ses.id, { status: "failed", endTime: Date.now(), error: errorMessage });
      entry.status = "failed";
      entry.endTime = Date.now();
      entry.error = errorMessage;

      ctx.ui?.setStatus("agent-chain", undefined);
      return {
        content: [{ type: "text" as const, text: `Chain failed at step ${i + 1} (${check.name}): ${errorMessage}` }],
        details: { mode: "chain" as const, results, totalUsage: totalUsage(results) },
        isError: true,
      };
    }
  }

  ctx.ui?.setStatus("agent-chain", undefined);
  return {
    content: [{ type: "text" as const, text: `Chain completed successfully (${chainSteps.length} steps).\n\nFinal output:\n${previousOutput}` }],
    details: { mode: "chain" as const, results, totalUsage: totalUsage(results) },
  };
}

// ── Team Mode ──

export async function executeTeamMode(
  teamTasks: Array<{ agent: string | Record<string, any>; task: string; produces?: string[]; cwd?: string }>,
  ctx: ExtensionContext,
  signal: AbortSignal | undefined,
  forkCtx: ForkContext,
  agents?: AgentConfig[],
): Promise<{ content: Array<{ type: "text"; text: string }>; details: AgentToolDetail; isError?: boolean }> {
  const allAgents = agents ?? discoverAgents(ctx.cwd);

  if (teamTasks.length > MAX_PARALLEL_TASKS) {
    return {
      content: [{ type: "text" as const, text: `Too many team members (${teamTasks.length}). Maximum is ${MAX_PARALLEL_TASKS}.` }],
      details: { mode: "team" as const, results: [], totalUsage: emptyUsage() },
      isError: true,
    };
  }

  // ── Create shared team directory and task list ──
  const teamId = `team-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const teamDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), `${teamId}-`));
  const memberNames: string[] = [];
  const memberTasks: string[] = [];

  for (const t of teamTasks) {
    const { name } = resolveAgentRef(t.agent, allAgents);
    memberNames.push(name);
    memberTasks.push(t.task);
  }

  // ── Write initial task list to shared directory ──
  const taskList = teamTasks.map((t, i) => ({
    id: `task-${i + 1}`,
    assignee: memberNames[i],
    description: t.task,
    status: "pending" as const,
    dependsOn: [] as string[],
  }));
  try {
    await fs.promises.writeFile(
      path.join(teamDir, "tasks.json"),
      JSON.stringify(taskList, null, 2),
      { encoding: "utf-8", mode: 0o644 },
    );
  } catch {
    // Non-fatal: task list is advisory, not required
  }

  const teamContext: TeamContext = { teamId, teamDir, memberNames, memberTasks };

  const results: RunResult[] = new Array(teamTasks.length).fill(null);
  ctx.ui?.setStatus("agent-team", `Team of ${teamTasks.length} members running...`);

  await mapWithLimit(teamTasks, MAX_CONCURRENCY, async (task, i) => {
    const { config, name } = resolveAgentRef(task.agent, allAgents);

    const entry = getOrCreateEntry(name);
    entry.status = "running";
    entry.startTime = Date.now();

    const ses = addSession({ agentName: name, task: task.task, mode: "team" as const, status: "running", background: false });

    try {
      const result = await runAgent(config, task.task, {
        cwd: task.cwd || ctx.cwd,
        signal,
        produces: task.produces,
        forkContext: isForkType(config) ? forkCtx : undefined,
        teamContext,
      });

      results[i] = result;
      entry.status = isFailed(result) ? "failed" : "done";
      entry.endTime = Date.now();
      entry.usage = result.usage;
      updateSession(ses.id, {
        status: isFailed(result) ? "failed" : "done",
        endTime: Date.now(),
        output: result.output,
        error: result.errorMessage,
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      results[i] = makeFailedResult(name, task.task, errorMessage);
      entry.status = "failed";
      entry.endTime = Date.now();
      entry.error = errorMessage;
      updateSession(ses.id, { status: "failed", endTime: Date.now(), error: errorMessage });
    }
  });

  ctx.ui?.setStatus("agent-team", undefined);

  // ── Collect results from shared directory ──
  const sharedOutputs: string[] = [];
  try {
    const files = await fs.promises.readdir(teamDir);
    for (const f of files.sort()) {
      const fp = path.join(teamDir, f);
      const content = await fs.promises.readFile(fp, "utf-8");
      sharedOutputs.push(`### ${f}\n\n\`\`\`json\n${content.slice(0, 2000)}\n\`\`\``);
    }
  } catch {}

  // Cleanup team directory
  try { await fs.promises.rm(teamDir, { recursive: true, force: true }); } catch {}

  const successCount = results.filter((r) => !isFailed(r)).length;
  const output = results.map((r, i) => {
    const status = isFailed(r) ? "❌ Failed" : "✅ Success";
    return `**Task ${i + 1}** (${r.agent}): ${status}\n\n${r.output || r.errorMessage || "(no output)"}`;
  }).join("\n\n---\n\n");

  const sharedSection = sharedOutputs.length > 0
    ? `\n\n### Shared Message Board Outputs\n\n${sharedOutputs.join("\n\n")}`
    : "";

  return {
    content: [{ type: "text" as const, text: `Team execution completed: ${successCount}/${teamTasks.length} succeeded.${sharedSection}\n\n${output}` }],
    details: { mode: "team" as const, results, totalUsage: totalUsage(results) },
  };
}